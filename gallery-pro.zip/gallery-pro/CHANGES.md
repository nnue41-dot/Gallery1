# fix-004 (round 4)

## Operations: progress window
- src/services/progress.js + src/components/ProgressOverlay.js: a dark progress window with a bar and "x / y" during copy, move, trash, restore, and permanent delete. Copy/move/trash count per item; the system delete step shows an indeterminate spinner.

## Delete confirmation
- src/components/ConfirmDialog.js: dark card with a red delete button. Used in the grid (multi-select delete), the viewer, and the trash viewer. The system dialog follows after confirming.

## Undo after trash
- src/components/UndoBar.js: 5-second bar at the bottom with "تراجع" after moving items to trash.

## Trash
- Media type checks fixed: MediaLibrary uses "photo"/"video", not "image". Photos were treated as videos in trash and viewer.
- Trash tiles show real thumbnails (photos from file, videos from a frame).
- Tap an item: opens src/screens/TrashViewer.js with two buttons at the bottom: استعادة and حذف نهائي.
- Long-press selects several items; bottom bar restores or deletes them.

## Date scrubber
- src/components/DateScrubber.js: floating, takes no layout space. Appears only while scrolling; drag it to jump; shows month/year in a bubble.

## Thumbnails after restart
- src/services/thumbs.js: index of thumbnails is saved and loaded at startup, so tiles show their thumbnail on the first frame without regenerating. Thumbnails are small JPEGs (320 px).

## Pull to refresh
- Main grid: pull down to reload the library.

## fix-005: slow start and thumbnails reloading on every launch
- The thumbnail index was read asynchronously after the first screen rendered, so every tile searched for its file. The index is now loaded before the first screen (App.js) and stored as a file, not AsyncStorage (size limit on large libraries).
- Library list is cached per view (src/services/libcache.js). On launch the last list appears immediately; a fresh scan replaces it in the background.
- Vertical scroll indicator hidden in the grid (the black line on the right).
- Date scrubber touch area is active only while it is visible.

## fix-006 (round 6)
1. Background audio: VideoPlayer now uses expo-video. Headphones toggle in the viewer top bar (videos only); it turns blue when active and keeps audio playing in the background and with the screen locked (allowsBackgroundPlayback + foreground service from the expo-video plugin). Requires a native rebuild (expo prebuild) and notification permission on Android 13+.
2. Navigation bar: androidNavigationBar.barStyle = dark-content in app.json and setButtonStyleAsync('dark') in App.js, so the buttons are dark. Dark icons need a light bar; they are not visible on a dark bar.
3. Multi-selection header: select-all and trash icons are in the top bar; the three-dot menu keeps copy, move, and favorite.
4. Long press: tiles use an explicit 350 ms press timer (onPressIn/onPressOut) instead of Pressable's onLongPress, for all grids including Favorites. Cause not reproduced; needs device check.

## fix-007 (round 7)
1. Navigation bar: dark background (#07101F) with light icons (app.json androidNavigationBar, expo-system-ui for the window background). Dark icons cannot be seen on a dark bar, so the icons are light now.
2. Grid loading: one state update per second at most while scanning; fewer, larger pages (1000); fixed row layout (getItemLayout) so scrolling does not measure items. With a saved list, the grid shows it immediately and replaces it once after the scan.
3. Thumbnails: the thumbs directory is the source of truth. On startup it is listed once and fills the in-memory map; no per-file checks and no index file. Generated thumbnails are never deleted by the app.

## fix-008 (round 8)
1. Folder caching: folder contents are kept in memory and on disk (libcache). Reopening a folder shows its cached items at once. A new scan runs only when the folder's item count changed. After the folder list loads, each folder is cached in the background (src/services/folderCache.js), so the first visit is instant too.
2. Folder filtering (src/services/media.js, listAlbums):
   - Removed folders with zero photos or videos (verified with a one-item query).
   - Removed hidden folders (name starts with a dot) and unnamed buckets.
   - Removed system folders (Android, cache, thumbnails, notifications, ringtones, alarms, podcasts, system, trashed) and any name containing "cache" or "thumbnail".
   - Smart albums are off (includeSmartAlbums: false).
   The same filtered list is used by the folder picker for copy and move.

## fix-009 (round 9)
1. Freeze after move/copy:
   - Copy and move now yield to the UI between items.
   - Folder prefetch pauses while a file operation runs.
   - Cache files are written after interactions finish (libcache.js).
   - After a move, the list is updated locally; the full reload runs later, after interactions.
2. Trash icon in the selection header is white (#FFFFFF).
3. Viewer bottom bar: delete is now in the share position and share is in the delete position.

## fix-010 (round 10)
- Main grid: two tabs above the grid, "الصور" (photos) and "الفيديوهات" (videos). Tapping a tab filters the grid to that type; tapping the active tab again shows all items. Tabs are hidden in folder views, favorites, and during selection. Filtering is applied to the cached list, so no rescan happens.

## fix-011 (round 11): tab switching and viewer swiping
1. Tabs: date order is computed once per scan; the tabs only filter that list. Tab changes run as transitions so the UI stays responsive. The tile render function no longer depends on the list.
2. Viewer swiping:
   - Local URIs are cached per asset (media.js), so each slide does not wait for a native call.
   - Photos show their cached thumbnail while the full image decodes.
   - Slides are memoized and receive stable callbacks, so swiping re-renders only the slides that changed.
   - Only the active video has a player; neighbouring videos show their thumbnail with a play icon.

## fix-012 (round 12): free-form crop
1. Presets removed (free, 1:1, 4:3, 16:9). The crop is free-form: drag the frame, any corner, or any edge (src/components/CropSheet.js). Larger touch targets (32 px).
2. Saving creates a new media item from a temporary file. The original is not modified or replaced.

## fix-013 (round 13): settings, themes, folder layouts
- Settings button in the main header (next to Sort). Screen with two sections:
  - Theme: "رمادي" (gray) and "أسود داكن" (black). Applied immediately to every screen and persisted.
  - Folder layout: list (default), 2, 3, or 4 columns. Grid cards show a cached cover thumbnail.
- Theme system: src/theme.js (THEMES, AppContext, useThemeColors, useStyles). Every component reads colors from context; styles are rebuilt when the theme changes.
- Settings persisted in settings.json (src/services/settings.js).

## fix-014: viewer swiping and black frames
- Neighbouring videos (one before, one after) are loaded paused, so they are ready when reached.
- Far items show only their cached thumbnail (generated if missing).
- Each video shows its thumbnail as a poster until the first frame is rendered (onFirstFrameRender), then the poster fades out. This removes the black frame while the player starts.
- Paging uses disableIntervalMomentum and decelerationRate="fast" for quicker, one-item swipes.
- Fixed a missing style (`full`) used by thumbnail-only slides.

## fix-015: install conflict with an existing gallery app
- Android package changed from com.galleryPro.app to com.personal.gallerypro2 (lowercase, unique).
- App name changed to "Gallery Pro 2" and slug to gallery-pro-2.
- The new app installs alongside the existing gallery app; nothing needs to be uninstalled.

## fix-016: image and video info
- Info dialog shows the folder name, the full file path, and the date.
- Date: uses creation time, then modification time; seconds are converted to milliseconds; shows a dash only when no time exists.
- The grid passes the folder name to the viewer when opened from a folder.

## fix-017: photo framing and grid thumbnail size
- Viewer photos use contain: the whole photo is visible, with black bands where its shape differs from the screen (no cropping on the sides).
- Grid thumbnails: 200 px wide, JPEG quality 0.45 (was 320 px, 0.7). New cache folder thumbs-q2; the old thumbs folder is deleted once at startup. Thumbnails regenerate on the first open after this update.

## fix-018: viewer smoothness, search, favorites removal, multi-share, tall photos
1. Viewer swiping: gesture-aware FlatList (react-native-gesture-handler); video progress polling only for the active item; neighbouring players stay paused.
2. Search: magnifier icon in the main header; a search field filters the grid by file name.
3. Favorites view: the overflow menu offers "إزالة من المفضلة" for selected items (removes them from favorites).
4. Share: new share icon in the selection header. One item is shared directly; several items are packed into one ZIP (stored, not compressed) and shared once.
5. Tall photos: the viewer uses the measured size of its own area (not the window size), so a tall screenshot fills the height correctly.
- Dependency added: jszip.

## fix-019: smoothness toward 60 fps
- Date scrubber: position is driven by an Animated value. Scrolling no longer re-renders the whole gallery screen on every frame; only a month change does.
- Grid: fewer cells kept around the viewport (windowSize 5), batched cell updates every 50 ms, no fade transition on each thumbnail.
- Video and photo viewer: unchanged in this round (already on the UI thread for zoom and gestures).

## How to check the frame rate on the phone
1. Settings > About phone > tap Build number seven times to enable developer options.
2. Developer options > Profile GPU rendering > On screen as bars.
3. Scroll the grid, the folders, and the viewer. Bars above the 16 ms line mean dropped frames.

## Final package
- Identity: "Gallery Pro 2", package com.personal.gallerypro2.
- Feature set and dependencies are listed in GALLERY_PRO_INSTRUCTIONS.md (sections 5 and 9).

## fix-020: first launch shows the grid at once
- The grid appears as soon as the first items are scanned; it refreshes about 4 times per second during the scan (previously once per second, and the spinner stayed until the first batch).
- Each tile shows a placeholder until its own thumbnail is ready, then the thumbnail fades in (240 ms). Only visible tiles request thumbnails, so the tiles on screen are generated first.
- During a first scan, a partial list is saved every 3000 items, so an interrupted first scan is not repeated from zero.
- Build package: see GALLERY_PRO_INSTRUCTIONS.md (sections 5, 9, 9b, 10).

## fix-021: new media viewer
- ViewerScreen rewritten with a simpler structure:
  - Native pager (react-native-pager-view) for swiping; only neighbours are kept mounted.
  - Photos: pinch zoom to 5x, double-tap zoom, pan when zoomed; pager swiping is disabled while zoomed.
  - Videos: expo-video; poster until the first frame, then fade; progress bar; back/forward 10 s; mute; replay at end; headphones toggle for background audio.
  - Top bar: back, name, counter, headphones (videos) or crop (photos).
  - Bottom bar: delete, rotate (photos), favorite, info, share.
  - Info dialog: name, folder, path, date, dimensions, duration, size.
- Dependency added: react-native-pager-view.
- Not included in this rewrite: fullscreen toggle and double-tap side skip for video.
