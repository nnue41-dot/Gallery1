// After the folder list loads, fill the cache of each folder in the background (one at a time),
// so the first visit to a folder is also instant.
import * as Media from './media';
import { readLibCache, writeLibCache, setScanCount } from './libcache';
import { isOperationActive } from './progress';

const done = new Set();

export async function prefetchFolders(albums) {
  for (const al of albums) {
    while (isOperationActive()) await new Promise((r) => setTimeout(r, 500));
    const sig = `${al.id}:${al.assetCount}`;
    if (done.has(sig)) continue;
    done.add(sig);
    const key = `gallerypro:lib:${al.id}`;
    try {
      const cached = await readLibCache(key);
      if (cached.length && cached.length === al.assetCount) continue;
      const fresh = [];
      await Media.listAssets({ albumId: al.id, onChunk: (c) => { fresh.push(...c); } });
      await writeLibCache(key, fresh);
      setScanCount(key, al.assetCount);
    } catch {
      done.delete(sig);
    }
    await new Promise((r) => setTimeout(r, 300));
  }
}
