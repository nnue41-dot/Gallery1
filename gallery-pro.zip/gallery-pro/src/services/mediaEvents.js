// Tiny event bus so the viewer can tell the grid about deletes, favorites and edits.
const listeners = new Set();

export function emitMediaChange(event) {
  listeners.forEach((fn) => {
    try { fn(event); } catch { /* a listener must never crash the emitter */ }
  });
}

export function onMediaChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
