// Media lists per view. Kept in memory for the session and in a JSON file across restarts.
// File writes run after UI interactions finish, so they never block a tap or a scroll.
import * as FileSystem from 'expo-file-system';
import { InteractionManager } from 'react-native';

const DIR = `${FileSystem.documentDirectory}libcache/`;
const pathFor = (key) => `${DIR}${key.replace(/[^a-zA-Z0-9_-]/g, '_')}.json`;
const memCache = new Map();
const scanCounts = new Map();

const slim = (a) => ({
  id: a.id, filename: a.filename, uri: a.uri, mediaType: a.mediaType, duration: a.duration,
  width: a.width, height: a.height, creationTime: a.creationTime, modificationTime: a.modificationTime,
});

export async function readLibCache(key) {
  if (memCache.has(key)) return memCache.get(key);
  try {
    const p = pathFor(key);
    const info = await FileSystem.getInfoAsync(p);
    if (!info.exists) return [];
    const data = JSON.parse(await FileSystem.readAsStringAsync(p));
    memCache.set(key, data);
    return data;
  } catch {
    return [];
  }
}

export function writeLibCache(key, list) {
  const data = list.map(slim);
  memCache.set(key, data);
  InteractionManager.runAfterInteractions(async () => {
    try {
      await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
      await FileSystem.writeAsStringAsync(pathFor(key), JSON.stringify(data));
    } catch { /* cache is optional */ }
  });
}

export function setScanCount(key, n) { scanCounts.set(key, n); }
export function getScanCount(key) { return scanCounts.get(key); }
