import * as MediaLibrary from 'expo-media-library';
import * as IntentLauncher from 'expo-intent-launcher';
import { Platform } from 'react-native';
import { tickProgress } from './progress';

const MEDIA = ['photo', 'video'];
// Yield to the event loop between pages so the UI thread never stalls during scans.
const yieldToUI = () => new Promise((r) => setTimeout(r, 0));

export async function ensurePermission() {
  const current = await MediaLibrary.getPermissionsAsync(false, MEDIA);
  if (current.granted) return true;
  const { granted } = await MediaLibrary.requestPermissionsAsync(false, MEDIA);
  return granted;
}

// MANAGE_EXTERNAL_STORAGE cannot be granted via a runtime dialog; send the user to the settings screen.
export async function openAllFilesAccess() {
  if (Platform.OS !== 'android') return;
  await IntentLauncher.startActivityAsync('android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION').catch(() => {});
}

export async function listAssets({ albumId, onChunk } = {}) {
  const all = [];
  let after;
  let more = true;
  while (more) {
    const page = await MediaLibrary.getAssetsAsync({
      first: 1000,
      after,
      album: albumId,
      mediaType: MEDIA,
      sortBy: [[MediaLibrary.SortBy.creationTime, false]],
    });
    all.push(...page.assets);
    onChunk?.(page.assets);
    more = page.hasNextPage;
    after = page.endCursor;
    await yieldToUI();
  }
  return all;
}

const SYSTEM_NAMES = ['android', 'cache', 'thumbnails', 'notifications', 'ringtones', 'alarms', 'podcasts', 'system', 'trashed'];
const probeMemo = new Map();

// Hidden folders (leading dot), system/cache folders, and unnamed buckets are excluded.
function isSystemAlbum(album) {
  const t = (album.title || '').trim();
  const l = t.toLowerCase();
  if (!t || t.startsWith('.')) return true;
  if (SYSTEM_NAMES.includes(l)) return true;
  return l.includes('cache') || l.includes('thumbnail');
}

// Confirms the folder holds at least one photo or video (result memoized per album and count).
async function hasMedia(album) {
  const sig = `${album.id}:${album.assetCount}`;
  if (probeMemo.has(sig)) return probeMemo.get(sig);
  let ok = false;
  try {
    const p = await MediaLibrary.getAssetsAsync({ album: album.id, first: 1, mediaType: MEDIA });
    ok = p.assets.length > 0;
  } catch {
    ok = false;
  }
  probeMemo.set(sig, ok);
  return ok;
}

export async function listAlbums() {
  const all = await MediaLibrary.getAlbumsAsync({ includeSmartAlbums: false });
  const candidates = all.filter((al) => al.assetCount > 0 && !isSystemAlbum(al));
  const out = [];
  for (const al of candidates) {
    if (await hasMedia(al)) out.push(al);
    await new Promise((r) => setTimeout(r, 0));
  }
  return out.sort((x, y) => y.assetCount - x.assetCount);
}

const localMemo = new Map();

export async function resolveLocalUri(asset) {
  if (localMemo.has(asset.id)) return localMemo.get(asset.id);
  try {
    const info = await MediaLibrary.getAssetInfoAsync(asset);
    const uri = info.localUri || asset.uri;
    localMemo.set(asset.id, uri);
    return uri;
  } catch {
    return asset.uri;
  }
}

const yieldUI = () => new Promise((r) => setTimeout(r, 0));

export async function copyAssets(assets, targetAlbum) {
  if (targetAlbum) {
    for (const a of assets) {
      await MediaLibrary.addAssetsToAlbumAsync([a], targetAlbum, false);
      tickProgress(1);
      await yieldUI();
    }
    return assets.length;
  }
  for (const a of assets) {
    await MediaLibrary.createAssetAsync(await resolveLocalUri(a));
    tickProgress(1);
    await yieldUI();
  }
  return assets.length;
}

export async function moveAssets(assets, targetAlbum) {
  if (targetAlbum) {
    for (let i = 0; i < assets.length; i += 10) {
      const chunk = assets.slice(i, i + 10);
      await MediaLibrary.addAssetsToAlbumAsync(chunk, targetAlbum, true);
      tickProgress(chunk.length);
      await yieldUI();
    }
    return assets.length;
  }
  await copyAssets(assets, null);
  await MediaLibrary.deleteAssetsAsync(assets);
  return assets.length;
}

export function deleteAssets(assets) {
  return MediaLibrary.deleteAssetsAsync(assets);
}
