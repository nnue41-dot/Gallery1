// Operation progress (copy / move / delete / restore). total = 0 means "in progress, unknown count".
import { emitMediaChange } from './mediaEvents';

let current = null;
let active = false;

export function startProgress(title, total) {
  active = true;
  current = { title, total, done: 0 };
  emitMediaChange({ type: 'progress', state: { ...current } });
}

export function tickProgress(n = 1) {
  if (!current) return;
  current.done = Math.min(current.total, current.done + n);
  emitMediaChange({ type: 'progress', state: { ...current } });
}

export function endProgress() {
  active = false;
  current = null;
  emitMediaChange({ type: 'progress', state: null });
}

export function isOperationActive() {
  return active;
}
