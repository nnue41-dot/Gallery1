// Shares several photos and videos in one action. Android's share sheet takes one file via
// expo-sharing, so the selection is packed into a single ZIP (stored, not compressed: media
// files are already compressed) and that ZIP is shared once. One item is shared directly.
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import JSZip from 'jszip';
import * as Media from './media';

const yieldUI = () => new Promise((r) => setTimeout(r, 0));

export async function shareAssets(assets, onStep) {
  if (!assets.length) return;
  if (!(await Sharing.isAvailableAsync())) throw new Error('sharing unavailable');

  if (assets.length === 1) {
    const a = assets[0];
    const uri = await Media.resolveLocalUri(a);
    await Sharing.shareAsync(uri, {
      mimeType: a.mediaType === 'video' ? 'video/mp4' : 'image/jpeg',
      dialogTitle: 'مشاركة',
    });
    onStep && onStep();
    return;
  }

  const zip = new JSZip();
  for (let i = 0; i < assets.length; i += 1) {
    const a = assets[i];
    const uri = await Media.resolveLocalUri(a);
    const b64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
    zip.file(`${i + 1}_${a.filename || 'file'}`, b64, { base64: true });
    onStep && onStep();
    await yieldUI();
  }
  const out = await zip.generateAsync({ type: 'base64', compression: 'STORE' });
  const dest = `${FileSystem.cacheDirectory}gallery-share-${Date.now()}.zip`;
  await FileSystem.writeAsStringAsync(dest, out, { encoding: FileSystem.EncodingType.Base64 });
  await Sharing.shareAsync(dest, { mimeType: 'application/zip', dialogTitle: 'مشاركة' });
}
