// App-level recycle bin. Media is copied to app-private storage, then removed from the gallery.
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Alert } from 'react-native';
import * as Media from './media';
import { startProgress, tickProgress, endProgress } from './progress';

const KEY = 'gallerypro:trash';
const DIR = `${FileSystem.documentDirectory}trash/`;
const DAY = 86400000;
const RETENTION_DAYS = 30;

async function readIndex() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

async function writeIndex(items) {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(items));
  } catch { /* never crash on storage errors */ }
}

export function daysLeft(item) {
  return Math.max(0, Math.ceil((item.deletedAt + RETENTION_DAYS * DAY - Date.now()) / DAY));
}

export async function listTrash() {
  return readIndex();
}

// Checks the MediaStore directly. The delete call's return value is not trusted,
// because it can report failure even after the user confirmed the system dialog.
async function stillExists(asset) {
  try {
    const info = await MediaLibrary.getAssetInfoAsync(asset);
    return !!(info && info.id);
  } catch {
    return false;
  }
}

// Polls MediaStore a few times: the system can take a moment to update its index.
async function goneIds(assets) {
  let ids = [];
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const remaining = await Promise.all(assets.map(stillExists));
    ids = assets.filter((_, i) => !remaining[i]).map((a) => a.id);
    if (ids.length === assets.length) break;
    await new Promise((r) => setTimeout(r, 700));
  }
  return new Set(ids);
}

let lastDiag = '';
let lastBatch = [];
export function getLastDiag() { return lastDiag; }

// Direct file deletion: only works when All Files Access is granted (MANAGE_EXTERNAL_STORAGE).
async function directDelete(asset) {
  try {
    const info = await MediaLibrary.getAssetInfoAsync(asset);
    const path = info && info.localUri;
    if (!path) return 'no-path';
    await FileSystem.deleteAsync(path, { idempotent: true });
    const after = await FileSystem.getInfoAsync(path);
    return after.exists ? `still-exists:${path}` : 'deleted';
  } catch (e) {
    return `error:${String(e && e.message ? e.message : e).slice(0, 120)}`;
  }
}

export async function moveToTrash(assets, albumTitle = null) {
  if (!assets.length) return false;
  const diag = [];
  startProgress('نقل إلى السلة', assets.length);
  try {
    await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
    const index = await readIndex();
    const added = [];
    for (const a of assets) {
      const src = await Media.resolveLocalUri(a);
      const ext = (a.filename.split('.').pop() || 'bin').toLowerCase();
      const dest = `${DIR}${a.id}_${Date.now()}_${added.length}.${ext}`;
      await FileSystem.copyAsync({ from: src, to: dest });
      added.push({
        id: a.id, trashUri: dest, filename: a.filename, mediaType: a.mediaType,
        duration: a.duration, width: a.width, height: a.height,
        creationTime: a.creationTime, album: albumTitle, deletedAt: Date.now(),
      });
      tickProgress(1);
    }
    await writeIndex([...added, ...index]);

    startProgress('جارٍ الحذف من المعرض', 0);
    let ret = 'none';
    try {
      ret = String(await MediaLibrary.deleteAssetsAsync(assets));
    } catch (e) {
      ret = `threw:${String(e && e.message ? e.message : e).slice(0, 120)}`;
    }
    diag.push(`deleteAssetsAsync=${ret}`);

    let gone = await goneIds(assets);
    if (gone.size < assets.length) {
      for (const a of assets) {
        if (gone.has(a.id)) continue;
        const r = await directDelete(a);
        diag.push(`direct:${r}`);
        if (r === 'deleted') gone.add(a.id);
      }
    }

    const kept = added.filter((m) => gone.has(m.id));
    const dropped = added.filter((m) => !gone.has(m.id));
    await Promise.all(dropped.map((m) => FileSystem.deleteAsync(m.trashUri, { idempotent: true }).catch(() => {})));
    await writeIndex([...kept, ...index]);
    lastBatch = kept;
    lastDiag = `عدد العناصر: ${assets.length}، نجح: ${kept.length}\n${diag.join('\n')}`;
    if (kept.length) emitMediaChange({ type: 'trashed', count: kept.length });
    return kept.length > 0;
  } finally {
    endProgress();
  }
}

export async function undoLastTrash() {
  const batch = lastBatch;
  lastBatch = [];
  return restoreItems(batch);
}

export function showDeleteFailure() {
  Alert.alert('تعذر الحذف', getLastDiag() || 'لا توجد تفاصيل', [
    { text: 'إغلاق', style: 'cancel' },
    { text: 'إعدادات الملفات', onPress: () => Media.openAllFilesAccess() },
  ]);
}

async function addToOriginalAlbum(asset, title) {
  if (!title) return;
  const albums = await MediaLibrary.getAlbumsAsync();
  const target = albums.find((al) => al.title === title);
  if (target) await MediaLibrary.addAssetsToAlbumAsync([asset], target, true);
}

export async function restoreItems(items) {
  startProgress('استرجاع', items.length);
  let restored = 0;
  try {
    let index = await readIndex();
    for (const it of items) {
      try {
        const asset = await MediaLibrary.createAssetAsync(it.trashUri);
        await addToOriginalAlbum(asset, it.album);
        await FileSystem.deleteAsync(it.trashUri, { idempotent: true });
        index = index.filter((x) => x.trashUri !== it.trashUri);
        restored += 1;
      } catch { /* item stays in trash */ }
      tickProgress(1);
    }
    await writeIndex(index);
    return restored;
  } finally {
    endProgress();
  }
}

export async function permanentDelete(items, silent = false) {
  if (!silent) startProgress('حذف نهائي', items.length);
  try {
    let index = await readIndex();
    for (const it of items) {
      await FileSystem.deleteAsync(it.trashUri, { idempotent: true }).catch(() => {});
      index = index.filter((x) => x.trashUri !== it.trashUri);
      if (!silent) tickProgress(1);
    }
    await writeIndex(index);
  } finally {
    if (!silent) endProgress();
  }
}

export async function purgeOldTrash() {
  try {
    const index = await readIndex();
    const expired = index.filter((x) => daysLeft(x) === 0);
    if (expired.length) await permanentDelete(expired, true);
  } catch { /* background task */ }
}
