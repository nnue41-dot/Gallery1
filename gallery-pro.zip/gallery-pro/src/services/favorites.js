import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'gallerypro:favorites';

export async function loadFavorites() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}

export async function saveFavorites(set) {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify([...set]));
  } catch {
    // Storage failure should never crash the UI; favorites simply stay in memory.
  }
}
