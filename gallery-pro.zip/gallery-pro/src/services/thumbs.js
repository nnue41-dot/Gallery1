// Thumbnails live in documentDirectory/thumbs/<id>_<modificationTime>.jpg and are never deleted
// by the app. On startup the directory is listed once (one native call), which fills the
// in-memory map. Tiles then resolve their thumbnail synchronously, with no per-file checks.
import * as FileSystem from 'expo-file-system';
import * as ImageManipulator from 'expo-image-manipulator';
import * as VideoThumbnails from 'expo-video-thumbnails';
import * as Media from './media';

const DIR = `${FileSystem.documentDirectory}thumbs-q2/`;
const OLD_DIR = `${FileSystem.documentDirectory}thumbs/`;
const mem = new Map();
const queue = [];
let running = 0;

export async function loadThumbIndex() {
  // Remove the previous higher-quality thumbnails once (they are only a cache).
  FileSystem.deleteAsync(OLD_DIR, { idempotent: true }).catch(() => {});
  try {
    const info = await FileSystem.getInfoAsync(DIR);
    if (!info.exists) return;
    const names = await FileSystem.readDirectoryAsync(DIR);
    names.forEach((n) => {
      if (n.endsWith('.jpg')) mem.set(n.slice(0, -4), `${DIR}${n}`);
    });
  } catch {
    // An unreadable cache directory just means thumbnails are generated again.
  }
}

export function thumbKey(a) {
  return `${a.id}_${a.modificationTime ?? 0}`;
}

export function cachedThumb(asset) {
  return mem.get(thumbKey(asset)) ?? null;
}

function pump() {
  while (running < 3 && queue.length) {
    const { task, resolve, reject } = queue.shift();
    running += 1;
    task().then(resolve, reject).finally(() => { running -= 1; pump(); });
  }
}

function run(task) {
  return new Promise((resolve, reject) => { queue.push({ task, resolve, reject }); pump(); });
}

export function getThumb(asset) {
  const key = thumbKey(asset);
  const hit = mem.get(key);
  if (hit) return Promise.resolve(hit);
  return run(async () => {
    const again = mem.get(key);
    if (again) return again;
    await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
    const local = await Media.resolveLocalUri(asset);
    let src = local;
    if (asset.mediaType === 'video') {
      src = (await VideoThumbnails.getThumbnailAsync(local, { time: 500 })).uri;
    }
    const out = await ImageManipulator.manipulateAsync(src, [{ resize: { width: 200 } }], {
      compress: 0.45, format: ImageManipulator.SaveFormat.JPEG,
    });
    const dest = `${DIR}${key}.jpg`;
    await FileSystem.moveAsync({ from: out.uri, to: dest });
    mem.set(key, dest);
    return dest;
  });
}
