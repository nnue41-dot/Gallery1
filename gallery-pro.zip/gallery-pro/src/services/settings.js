// User settings (theme, folder layout) stored as a small JSON file.
import * as FileSystem from 'expo-file-system';
import { DEFAULT_SETTINGS } from '../theme';

const FILE = `${FileSystem.documentDirectory}settings.json`;

export async function loadSettings() {
  try {
    const info = await FileSystem.getInfoAsync(FILE);
    if (!info.exists) return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...JSON.parse(await FileSystem.readAsStringAsync(FILE)) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

export async function saveSettings(settings) {
  try {
    await FileSystem.writeAsStringAsync(FILE, JSON.stringify(settings));
  } catch { /* settings are optional */ }
}
