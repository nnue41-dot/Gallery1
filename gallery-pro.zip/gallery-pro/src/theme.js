import React, { useContext, useMemo } from 'react';

export const THEMES = {
  gray: {
    bg: '#1C1F26', surface: '#252A33', surfaceAlt: '#313744', accent: '#2F6BFF',
    danger: '#B3262E', text: '#E8EDF7', muted: '#8A93A3', border: '#353B47',
  },
  black: {
    bg: '#000000', surface: '#0D0D0F', surfaceAlt: '#1A1A1F', accent: '#2F6BFF',
    danger: '#B3262E', text: '#F2F2F2', muted: '#7C7C85', border: '#1F1F24',
  },
};

export const DEFAULT_SETTINGS = { theme: 'black', folderLayout: 'list' };

// Legacy export (default theme). Screens must use useThemeColors() so theme changes apply.
export const colors = THEMES.black;

export const AppContext = React.createContext({
  settings: DEFAULT_SETTINGS,
  update: () => {},
  colors: THEMES.black,
});

export function useApp() {
  return useContext(AppContext);
}

export function useThemeColors() {
  return useContext(AppContext).colors;
}

// Styles are rebuilt only when the theme object changes.
export function useStyles(make) {
  const c = useThemeColors();
  return useMemo(() => make(c), [c, make]);
}
