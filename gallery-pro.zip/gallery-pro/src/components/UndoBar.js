import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { onMediaChange, emitMediaChange } from '../services/mediaEvents';
import { undoLastTrash } from '../services/trash';
import { useThemeColors, useStyles } from '../theme';

export default function UndoBar() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const [info, setInfo] = useState(null);

  useEffect(() => onMediaChange((ev) => {
    if (ev.type === 'trashed') setInfo({ count: ev.count, key: Date.now() });
  }), []);

  useEffect(() => {
    if (!info) return undefined;
    const t = setTimeout(() => setInfo(null), 5000);
    return () => clearTimeout(t);
  }, [info]);

  if (!info) return null;
  return (
    <View style={[styles.bar, { bottom: insets.bottom + 80 }]} pointerEvents="box-none">
      <Text style={styles.txt}>تم نقل {info.count} عنصر إلى السلة</Text>
      <Pressable
        hitSlop={10}
        onPress={async () => {
          setInfo(null);
          try { await undoLastTrash(); } catch { /* ignore */ }
          emitMediaChange({ type: 'changed' });
        }}
      >
        <Text style={styles.undo}>تراجع</Text>
      </Pressable>
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  bar: { position: 'absolute', left: 16, right: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#1B2438', borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12, borderWidth: 1, borderColor: colors.border },
  txt: { color: '#fff', fontSize: 14 },
  undo: { color: colors.accent, fontSize: 15, fontWeight: '700' },
});
