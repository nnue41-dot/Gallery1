import React, { useRef, useState } from 'react';
import { View, Text, StyleSheet, PanResponder, Animated } from 'react-native';
import { useStyles, useThemeColors } from '../theme';

const makeStyles = (colors) => StyleSheet.create({
  strip: { position: 'absolute', right: 0, width: 28 },
  thumb: { position: 'absolute', top: 0, right: 10, width: 4, height: 44, borderRadius: 2, backgroundColor: colors.accent },
  bubble: { position: 'absolute', top: 0, right: 26, backgroundColor: colors.accent, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  txt: { color: '#fff', fontSize: 12, fontWeight: '700' },
});

// Right-edge scrubber. Its position comes from an Animated value, so scrolling never re-renders React.
export default function DateScrubber({ anim, label, show, onDrag, top, bottom }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const [h, setH] = useState(1);
  const hRef = useRef(1);
  const cb = useRef(onDrag);
  cb.current = onDrag;

  const drag = (y) => cb.current(Math.max(0, Math.min(1, y / hRef.current)));
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: (e) => drag(e.nativeEvent.locationY),
    onPanResponderMove: (e) => drag(e.nativeEvent.locationY),
  })).current;

  const travel = Math.max(0, h - 44);
  const thumbY = anim.interpolate({ inputRange: [0, 1], outputRange: [0, travel] });
  const bubbleY = anim.interpolate({ inputRange: [0, 1], outputRange: [10, travel + 10] });

  return (
    <View
      style={[styles.strip, { top, bottom }]}
      pointerEvents={show ? 'auto' : 'none'}
      onLayout={(e) => { hRef.current = e.nativeEvent.layout.height; setH(e.nativeEvent.layout.height); }}
      {...pan.panHandlers}
    >
      {show && <Animated.View style={[styles.thumb, { transform: [{ translateY: thumbY }] }]} pointerEvents="none" />}
      {show && label && (
        <Animated.View style={[styles.bubble, { transform: [{ translateY: bubbleY }] }]} pointerEvents="none">
          <Text style={styles.txt}>{label}</Text>
        </Animated.View>
      )}
    </View>
  );
}
