import React, { useEffect, useState } from 'react';
import { View, Text, Modal, StyleSheet, ActivityIndicator } from 'react-native';
import { onMediaChange } from '../services/mediaEvents';
import { useThemeColors, useStyles } from '../theme';

export default function ProgressOverlay() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const [st, setSt] = useState(null);
  useEffect(() => onMediaChange((ev) => {
    if (ev.type === 'progress') setSt(ev.state);
  }), []);

  const unknown = !st || !st.total;
  const pct = st && st.total ? (st.done / st.total) * 100 : 0;
  return (
    <Modal visible={!!st} transparent animationType="fade" statusBarTranslucent>
      <View style={styles.scrim}>
        <View style={styles.card}>
          <Text style={styles.title}>{st?.title}</Text>
          {unknown ? (
            <ActivityIndicator color={colors.accent} style={{ marginVertical: 12 }} />
          ) : (
            <View style={styles.track}><View style={[styles.fill, { width: `${pct}%` }]} /></View>
          )}
          <Text style={styles.sub}>{unknown ? 'جارٍ التنفيذ…' : `${st.done} / ${st.total}`}</Text>
        </View>
      </View>
    </Modal>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  scrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', padding: 32 },
  card: { width: '100%', maxWidth: 340, backgroundColor: '#121A2B', borderRadius: 20, padding: 22, borderWidth: 1, borderColor: colors.border, gap: 12 },
  title: { color: colors.text, fontSize: 17, fontWeight: '700', textAlign: 'center' },
  track: { height: 6, borderRadius: 3, backgroundColor: colors.surfaceAlt, overflow: 'hidden' },
  fill: { height: 6, backgroundColor: colors.accent, borderRadius: 3 },
  sub: { color: colors.muted, fontSize: 13, textAlign: 'center' },
});
