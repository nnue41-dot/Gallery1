import React, { useEffect } from 'react';
import { StyleSheet, Dimensions } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useSharedValue, useAnimatedStyle, withTiming, runOnJS } from 'react-native-reanimated';
import { Image } from 'expo-image';
import { useThemeColors, useStyles } from '../theme';

const { width: W, height: H } = Dimensions.get('window');
const MAX_SCALE = 5;
const DOUBLE_SCALE = 2.5;
const noop = () => {};

function limitX(s, w) { 'worklet'; return (w * (s - 1)) / 2; }
function limitY(s, h) { 'worklet'; return (h * (s - 1)) / 2; }
function clampN(v, lim) { 'worklet'; return Math.min(lim, Math.max(-lim, v)); }

export default function ZoomableImage({ uri, placeholder, active, zoomed, onZoomChange = noop, onSingleTap = noop, size = null }) {
  const bw = size?.w ?? W;
  const bh = size?.h ?? H;
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const scale = useSharedValue(1);
  const saved = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const stx = useSharedValue(0);
  const sty = useSharedValue(0);

  // Reset zoom when the user swipes away from this photo.
  useEffect(() => {
    if (!active) {
      scale.value = 1; saved.value = 1;
      tx.value = 0; ty.value = 0; stx.value = 0; sty.value = 0;
    }
  }, [active]);

  const pinch = Gesture.Pinch()
    .onUpdate((e) => {
      const s = Math.min(MAX_SCALE, Math.max(1, saved.value * e.scale));
      scale.value = s;
      tx.value = clampN(stx.value, limitX(s, bw));
      ty.value = clampN(sty.value, limitY(s, bh));
    })
    .onEnd(() => {
      if (scale.value <= 1.05) {
        scale.value = withTiming(1); tx.value = withTiming(0); ty.value = withTiming(0);
        saved.value = 1; stx.value = 0; sty.value = 0;
        runOnJS(onZoomChange)(false);
      } else {
        saved.value = scale.value; stx.value = tx.value; sty.value = ty.value;
        runOnJS(onZoomChange)(true);
      }
    });

  // Panning only when zoomed, so horizontal swipes still page between items at 1x.
  const pan = Gesture.Pan()
    .enabled(zoomed)
    .onUpdate((e) => {
      tx.value = clampN(stx.value + e.translationX, limitX(scale.value, bw));
      ty.value = clampN(sty.value + e.translationY, limitY(scale.value, bh));
    })
    .onEnd(() => { stx.value = tx.value; sty.value = ty.value; });

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(260)
    .onEnd((e) => {
      if (scale.value > 1.01) {
        scale.value = withTiming(1); tx.value = withTiming(0); ty.value = withTiming(0);
        saved.value = 1; stx.value = 0; sty.value = 0;
        runOnJS(onZoomChange)(false);
      } else {
        const s = DOUBLE_SCALE;
        const nx = clampN(-(e.x - W / 2) * (s - 1), limitX(s, bw));
        const ny = clampN(-(e.y - H / 2) * (s - 1), limitY(s, bh));
        scale.value = withTiming(s); tx.value = withTiming(nx); ty.value = withTiming(ny);
        saved.value = s; stx.value = nx; sty.value = ny;
        runOnJS(onZoomChange)(true);
      }
    });

  const singleTap = Gesture.Tap()
    .maxDuration(250)
    .onEnd((_e, success) => { if (success) runOnJS(onSingleTap)(); });

  const gesture = Gesture.Simultaneous(pinch, pan, Gesture.Exclusive(doubleTap, singleTap));

  const animated = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
  }));

  return (
    <GestureDetector gesture={gesture}>
      <Animated.View style={[{ width: bw, height: bh }, animated]}>
        <Image source={{ uri }} placeholder={placeholder ? { uri: placeholder } : undefined} style={{ width: bw, height: bh }} contentFit="contain" cachePolicy="memory-disk" transition={120} />
      </Animated.View>
    </GestureDetector>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  box: { width: W, height: H },
});
