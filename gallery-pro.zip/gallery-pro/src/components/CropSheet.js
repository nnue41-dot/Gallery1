// Free-form crop: drag the frame, any edge, or any corner. No preset ratios.
// Saving creates a NEW media item; the original file is never modified.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Modal, Alert, ActivityIndicator, PanResponder } from 'react-native';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImageManipulator from 'expo-image-manipulator';
import * as MediaLibrary from 'expo-media-library';
import { useThemeColors, useStyles } from '../theme';
import * as Media from '../services/media';

const MIN = 40;      // minimum crop size on screen (px)
const HANDLE = 32;   // touch target size (px)
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

export default function CropSheet({ visible, asset, onClose, onSaved }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const [uri, setUri] = useState(null);
  const [box, setBox] = useState(null);
  const [rect, setRect] = useState(null);
  const [busy, setBusy] = useState(false);
  const boxRef = useRef(null);
  const R = useRef(null);
  const start = useRef(null);

  useEffect(() => {
    if (!visible || !asset) return undefined;
    let live = true;
    setUri(null);
    setRect(null);
    Media.resolveLocalUri(asset).then((u) => { if (live) setUri(u); });
    return () => { live = false; };
  }, [visible, asset?.id]);

  // Where the image is drawn inside the area (contain fit).
  const geo = useMemo(() => {
    if (!box || !asset) return null;
    const w = asset.width || 1;
    const h = asset.height || 1;
    const s = Math.min(box.w / w, box.h / h);
    const dw = w * s;
    const dh = h * s;
    const x0 = (box.w - dw) / 2;
    const y0 = (box.h - dh) / 2;
    return { w, h, dw, dh, x0, y0, x1: x0 + dw, y1: y0 + dh };
  }, [box, asset?.id]);

  useEffect(() => {
    if (!geo) return;
    boxRef.current = geo;
    const r = { x: geo.x0, y: geo.y0, w: geo.dw, h: geo.dh };
    R.current = r;
    setRect(r);
  }, [geo]);

  // Handlers are created once. Kinds: move, corners (tl, tr, bl, br), edges (t, b, l, r).
  const handlers = useRef(null);
  if (!handlers.current) {
    const mk = (kind) => PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => { start.current = { ...R.current }; },
      onPanResponderMove: (_e, g) => {
        const b = boxRef.current;
        const s = start.current;
        if (!b || !s) return;
        let x; let y; let w; let h;
        if (kind === 'move') {
          x = clamp(s.x + g.dx, b.x0, b.x1 - s.w);
          y = clamp(s.y + g.dy, b.y0, b.y1 - s.h);
          w = s.w; h = s.h;
        } else {
          let l = s.x; let t = s.y; let r = s.x + s.w; let bt = s.y + s.h;
          if (kind.includes('l')) l = clamp(s.x + g.dx, b.x0, r - MIN);
          if (kind.includes('r')) r = clamp(s.x + s.w + g.dx, l + MIN, b.x1);
          if (kind.includes('t')) t = clamp(s.y + g.dy, b.y0, bt - MIN);
          if (kind.includes('b')) bt = clamp(s.y + s.h + g.dy, t + MIN, b.y1);
          x = l; y = t; w = r - l; h = bt - t;
        }
        R.current = { x, y, w, h };
        setRect(R.current);
      },
    });
    const kinds = ['move', 'tl', 'tr', 'bl', 'br', 't', 'b', 'l', 'r'];
    handlers.current = Object.fromEntries(kinds.map((k) => [k, mk(k)]));
  }

  const save = async () => {
    if (busy || !uri || !geo || !rect) return;
    setBusy(true);
    try {
      const k = geo.w / geo.dw; // image pixels per on-screen pixel
      const originX = Math.max(0, Math.round((rect.x - geo.x0) * k));
      const originY = Math.max(0, Math.round((rect.y - geo.y0) * k));
      const crop = {
        originX,
        originY,
        width: Math.max(1, Math.min(Math.round(rect.w * k), geo.w - originX)),
        height: Math.max(1, Math.min(Math.round(rect.h * k), geo.h - originY)),
      };
      // Writes a temporary file; the original asset is untouched.
      const out = await ImageManipulator.manipulateAsync(uri, [{ crop }], {
        compress: 0.95, format: ImageManipulator.SaveFormat.JPEG,
      });
      const copy = await MediaLibrary.createAssetAsync(out.uri);
      onSaved(copy);
      onClose();
    } catch {
      Alert.alert('خطأ', 'تعذر اقتصاص الصورة');
    } finally {
      setBusy(false);
    }
  };

  if (!asset) return null;
  const dim = { position: 'absolute', backgroundColor: 'rgba(0,0,0,0.6)' };
  const spots = rect ? [
    ['tl', rect.x, rect.y], ['tr', rect.x + rect.w, rect.y],
    ['bl', rect.x, rect.y + rect.h], ['br', rect.x + rect.w, rect.y + rect.h],
    ['t', rect.x + rect.w / 2, rect.y], ['b', rect.x + rect.w / 2, rect.y + rect.h],
    ['l', rect.x, rect.y + rect.h / 2], ['r', rect.x + rect.w, rect.y + rect.h / 2],
  ] : [];

  return (
    <Modal visible={visible} animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <View style={styles.root}>
        <View style={[styles.top, { paddingTop: insets.top + 10 }]}>
          <Pressable onPress={onClose} hitSlop={12}><Text style={styles.link}>إلغاء</Text></Pressable>
          <Text style={styles.title}>اقتصاص حر</Text>
          <Pressable onPress={save} disabled={busy || !geo} hitSlop={12}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.link}>حفظ نسخة</Text>}
          </Pressable>
        </View>

        <View
          style={styles.area}
          onLayout={(e) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
        >
          {geo && uri && (
            <>
              <Image source={{ uri }} style={{ position: 'absolute', left: geo.x0, top: geo.y0, width: geo.dw, height: geo.dh }} contentFit="fill" />
              {rect && (
                <>
                  <View pointerEvents="none" style={[dim, { left: geo.x0, top: geo.y0, width: geo.dw, height: rect.y - geo.y0 }]} />
                  <View pointerEvents="none" style={[dim, { left: geo.x0, top: rect.y + rect.h, width: geo.dw, height: geo.y1 - (rect.y + rect.h) }]} />
                  <View pointerEvents="none" style={[dim, { left: geo.x0, top: rect.y, width: rect.x - geo.x0, height: rect.h }]} />
                  <View pointerEvents="none" style={[dim, { left: rect.x + rect.w, top: rect.y, width: geo.x1 - (rect.x + rect.w), height: rect.h }]} />
                  <View
                    {...handlers.current.move.panHandlers}
                    style={{ position: 'absolute', left: rect.x, top: rect.y, width: rect.w, height: rect.h, borderWidth: 1.5, borderColor: '#fff' }}
                  />
                  {spots.map(([k, cx, cy]) => (
                    <View
                      key={k}
                      {...handlers.current[k].panHandlers}
                      style={[styles.handle, { left: cx - HANDLE / 2, top: cy - HANDLE / 2 }]}
                    />
                  ))}
                </>
              )}
            </>
          )}
        </View>

        <Text style={[styles.hint, { paddingBottom: insets.bottom + 16 }]}>
          اسحب الإطار أو أطرافه لتحديد الجزء المطلوب. الصورة الأصلية لن تتغير.
        </Text>
      </View>
    </Modal>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 10 },
  title: { color: '#fff', fontSize: 16, fontWeight: '700' },
  link: { color: colors.accent, fontSize: 16, fontWeight: '600' },
  area: { flex: 1, margin: 8 },
  handle: { position: 'absolute', width: HANDLE, height: HANDLE, borderRadius: HANDLE / 2, borderWidth: 2, borderColor: '#fff', backgroundColor: colors.accent },
  hint: { color: colors.muted, fontSize: 13, textAlign: 'center', paddingHorizontal: 24, paddingTop: 10 },
});
