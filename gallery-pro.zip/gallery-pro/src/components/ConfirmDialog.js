import React from 'react';
import { View, Text, Pressable, Modal, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useThemeColors, useStyles } from '../theme';

export default function ConfirmDialog({ visible, title, message, confirmText = 'حذف', cancelText = 'إلغاء', onCancel, onConfirm }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  return (
    <Modal visible={visible} transparent animationType="fade" statusBarTranslucent onRequestClose={onCancel}>
      <View style={styles.scrim}>
        <View style={styles.card}>
          <View style={styles.iconWrap}>
            <Ionicons name="trash-outline" size={26} color={colors.danger} />
          </View>
          <Text style={styles.title}>{title}</Text>
          <Text style={styles.msg}>{message}</Text>
          <View style={styles.row}>
            <Pressable style={[styles.btn, styles.cancel]} onPress={onCancel}>
              <Text style={styles.cancelTxt}>{cancelText}</Text>
            </Pressable>
            <Pressable style={[styles.btn, styles.danger]} onPress={onConfirm}>
              <Text style={styles.btnTxt}>{confirmText}</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  scrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.65)', alignItems: 'center', justifyContent: 'center', padding: 28 },
  card: { width: '100%', maxWidth: 360, backgroundColor: '#121A2B', borderRadius: 22, padding: 22, borderWidth: 1, borderColor: colors.border, alignItems: 'center', gap: 10 },
  iconWrap: { width: 52, height: 52, borderRadius: 26, backgroundColor: 'rgba(179,38,46,0.15)', alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  title: { color: colors.text, fontSize: 18, fontWeight: '700' },
  msg: { color: colors.muted, fontSize: 14, textAlign: 'center', lineHeight: 20 },
  row: { flexDirection: 'row', gap: 10, marginTop: 14, alignSelf: 'stretch' },
  btn: { flex: 1, paddingVertical: 13, borderRadius: 12, alignItems: 'center' },
  cancel: { backgroundColor: colors.surfaceAlt },
  cancelTxt: { color: colors.text, fontWeight: '600', fontSize: 15 },
  danger: { backgroundColor: colors.danger },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
