import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, PanResponder, Dimensions, Animated } from 'react-native';
import { Image } from 'expo-image';
import { useVideoPlayer, VideoView } from 'expo-video';
import { Ionicons } from '@expo/vector-icons';
import { useThemeColors, useStyles } from '../theme';

const { width: W } = Dimensions.get('window');
const SKIP = 10; // seconds
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const fmt = (sec = 0) => {
  const s = Math.floor(sec || 0);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

export default function VideoPlayer({ uri, active, showControls, onTap, bottomInset = 80, backgroundAudio = false, poster = null }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const player = useVideoPlayer(uri, (p) => { p.loop = false; });
  const [muted, setMuted] = useState(false);
  const [st, setSt] = useState({ pos: 0, dur: 0, playing: false, ended: false });
  const [scrub, setScrub] = useState(null);
  const [flash, setFlash] = useState(null);
  const [ready, setReady] = useState(false);
  const fade = useRef(new Animated.Value(1)).current;

  // A new source starts with the poster visible again.
  useEffect(() => { setReady(false); fade.setValue(1); }, [uri, fade]);
  useEffect(() => {
    if (!ready) return;
    Animated.timing(fade, { toValue: 0, duration: 180, useNativeDriver: true }).start();
  }, [ready, fade]);
  const trackW = useRef(1);
  const durRef = useRef(0);
  const tapRef = useRef({ t: 0, timer: null });
  durRef.current = st.dur;

  // Poll the player 4 times per second to keep the progress bar and buttons in sync.
  useEffect(() => {
    if (!active) return undefined;
    const id = setInterval(() => {
      setSt((prev) => ({
        pos: player.currentTime || 0,
        dur: player.duration || 0,
        playing: player.playing,
        ended: prev.ended && !player.playing,
      }));
    }, 250);
    const sub = player.addListener('playToEnd', () => {
      setSt((prev) => ({ ...prev, ended: true, playing: false }));
    });
    return () => { clearInterval(id); sub.remove(); };
  }, [player, active]);

  // Autoplay when this item becomes visible; pause when it leaves.
  useEffect(() => {
    if (active) player.play(); else player.pause();
  }, [active, player]);

  useEffect(() => { player.muted = muted; }, [muted, player]);

  // Headphones toggle: keeps audio playing when the app is in the background or the screen is locked.
  useEffect(() => { player.allowsBackgroundPlayback = !!backgroundAudio; }, [backgroundAudio, player]);

  useEffect(() => () => clearTimeout(tapRef.current.timer), []);

  const seekTo = (sec) => { player.currentTime = clamp(sec, 0, durRef.current || 0); };
  const seekBy = (delta) => seekTo((player.currentTime || 0) + delta);

  const togglePlay = () => {
    if (st.ended) { player.currentTime = 0; player.play(); return; }
    if (player.playing) player.pause(); else player.play();
  };

  // Draggable progress bar.
  const pctOf = (x) => clamp(x / trackW.current, 0, 1);
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onStartShouldSetPanResponderCapture: () => true,
    onMoveShouldSetPanResponderCapture: () => true,
    onPanResponderGrant: (e) => setScrub(pctOf(e.nativeEvent.locationX)),
    onPanResponderMove: (e) => setScrub(pctOf(e.nativeEvent.locationX)),
    onPanResponderRelease: (e) => {
      const p = pctOf(e.nativeEvent.locationX);
      setScrub(null);
      seekTo(p * durRef.current);
    },
    onPanResponderTerminate: () => setScrub(null),
  })).current;

  // Single tap toggles the UI; double tap on the left/right side skips 10 seconds.
  const handleBgPress = (e) => {
    const x = e.nativeEvent.locationX;
    const now = Date.now();
    const T = tapRef.current;
    if (now - T.t < 300) {
      clearTimeout(T.timer);
      T.timer = null;
      T.t = 0;
      const left = x < W / 2;
      seekBy(left ? -SKIP : SKIP);
      setFlash(left ? 'left' : 'right');
      setTimeout(() => setFlash(null), 500);
    } else {
      T.t = now;
      T.timer = setTimeout(() => { T.timer = null; onTap?.(); }, 300);
    }
  };

  const pct = scrub ?? (st.dur ? st.pos / st.dur : 0);
  const shownSec = scrub !== null ? scrub * st.dur : st.pos;

  return (
    <View style={StyleSheet.absoluteFill}>
      <Pressable style={StyleSheet.absoluteFill} onPress={handleBgPress}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          contentFit="contain"
          nativeControls={false}
          onFirstFrameRender={() => setReady(true)}
        />
      </Pressable>

      {poster && (
        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { opacity: fade }]}>
          <Image source={{ uri: poster }} style={StyleSheet.absoluteFill} contentFit="contain" />
        </Animated.View>
      )}

      {flash && (
        <View style={[styles.flash, flash === 'left' ? { left: 24 } : { right: 24 }]} pointerEvents="none">
          <Ionicons name={flash === 'left' ? 'play-back' : 'play-forward'} size={36} color="#fff" />
          <Text style={styles.flashText}>{flash === 'left' ? '-10s' : '+10s'}</Text>
        </View>
      )}

      {showControls && (
        <>
          <View style={styles.center} pointerEvents="box-none">
            <Pressable onPress={togglePlay} style={styles.big} hitSlop={10}>
              <Ionicons name={st.ended ? 'reload' : st.playing ? 'pause' : 'play'} size={40} color="#fff" />
            </Pressable>
          </View>

          <View style={[styles.bottom, { bottom: bottomInset }]}>
            <Text style={styles.time}>{fmt(shownSec)} / {fmt(st.dur)}</Text>
            <View
              style={styles.track}
              onLayout={(e) => { trackW.current = e.nativeEvent.layout.width; }}
              {...pan.panHandlers}
            >
              <View style={styles.trackBg} pointerEvents="none" />
              <View style={[styles.fill, { width: `${pct * 100}%` }]} pointerEvents="none" />
              <View style={[styles.knob, { left: `${pct * 100}%` }]} pointerEvents="none" />
            </View>
            <View style={styles.row}>
              <Pressable onPress={() => seekBy(-SKIP)} hitSlop={8}>
                <Ionicons name="play-back" size={22} color="#fff" />
              </Pressable>
              <Pressable onPress={togglePlay} hitSlop={8}>
                <Ionicons name={st.playing ? 'pause' : 'play'} size={24} color="#fff" />
              </Pressable>
              <Pressable onPress={() => seekBy(SKIP)} hitSlop={8}>
                <Ionicons name="play-forward" size={22} color="#fff" />
              </Pressable>
              <Pressable onPress={() => setMuted((m) => !m)} hitSlop={8}>
                <Ionicons name={muted ? 'volume-mute' : 'volume-high'} size={22} color="#fff" />
              </Pressable>
            </View>
          </View>
        </>
      )}
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  center: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  big: { backgroundColor: 'rgba(0,0,0,0.45)', borderRadius: 40, padding: 14 },
  bottom: { position: 'absolute', left: 0, right: 0, paddingHorizontal: 16 },
  time: { color: '#fff', fontSize: 12, marginBottom: 4 },
  track: { height: 28, justifyContent: 'center' },
  trackBg: { position: 'absolute', left: 0, right: 0, height: 3, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 2 },
  fill: { position: 'absolute', left: 0, height: 3, backgroundColor: colors.accent, borderRadius: 2 },
  knob: { position: 'absolute', width: 14, height: 14, borderRadius: 7, backgroundColor: '#fff', top: 7, marginLeft: -7 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4, paddingHorizontal: 8 },
  flash: { position: 'absolute', top: '40%', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)', padding: 10, borderRadius: 12 },
  flashText: { color: '#fff', fontSize: 12, fontWeight: '600' },
});
