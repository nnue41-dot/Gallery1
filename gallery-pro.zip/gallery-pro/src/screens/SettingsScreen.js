import React from 'react';
import { View, Text, Pressable, ScrollView, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { useApp, useStyles, useThemeColors } from '../theme';

const THEME_OPTIONS = [
  { key: 'gray', label: 'رمادي' },
  { key: 'black', label: 'أسود داكن' },
];

const LAYOUT_OPTIONS = [
  { key: 'list', label: 'قائمة عمودية (الافتراضي)' },
  { key: '2', label: 'شبكة بعمودين' },
  { key: '3', label: 'شبكة بثلاثة أعمدة' },
  { key: '4', label: 'شبكة بأربعة أعمدة' },
];

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  bar: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 16, paddingBottom: 12, backgroundColor: colors.surface },
  title: { color: colors.text, fontSize: 18, fontWeight: '700' },
  section: { color: colors.muted, fontSize: 13, fontWeight: '600', paddingHorizontal: 16, paddingTop: 20, paddingBottom: 8 },
  card: { backgroundColor: colors.surface, marginHorizontal: 12, borderRadius: 14, overflow: 'hidden', borderWidth: 1, borderColor: colors.border },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: colors.border },
  rowLast: { borderBottomWidth: 0 },
  label: { color: colors.text, fontSize: 15, flex: 1 },
  note: { color: colors.muted, fontSize: 12, paddingHorizontal: 16, paddingTop: 14, textAlign: 'center' },
});

export default function SettingsScreen() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { settings, update } = useApp();

  const option = (key, label, selected, onPress, last) => (
    <Pressable key={key} style={[styles.row, last && styles.rowLast]} onPress={onPress}>
      <Ionicons name={selected ? 'radio-button-on' : 'radio-button-off'} size={22} color={selected ? colors.accent : colors.muted} />
      <Text style={styles.label}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.root}>
      <View style={[styles.bar, { paddingTop: insets.top + 8 }]}>
        <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
          <Ionicons name="arrow-back" size={24} color={colors.text} />
        </Pressable>
        <Text style={styles.title}>الإعدادات</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}>
        <Text style={styles.section}>المظهر</Text>
        <View style={styles.card}>
          {THEME_OPTIONS.map((o, i) => option(
            o.key, o.label, settings.theme === o.key,
            () => update({ theme: o.key }), i === THEME_OPTIONS.length - 1,
          ))}
        </View>

        <Text style={styles.section}>عرض المجلدات</Text>
        <View style={styles.card}>
          {LAYOUT_OPTIONS.map((o, i) => option(
            o.key, o.label, settings.folderLayout === o.key,
            () => update({ folderLayout: o.key }), i === LAYOUT_OPTIONS.length - 1,
          ))}
        </View>

        <Text style={styles.note}>التغييرات تُطبَّق فوراً وتُحفظ تلقائياً.</Text>
      </ScrollView>
    </View>
  );
}
