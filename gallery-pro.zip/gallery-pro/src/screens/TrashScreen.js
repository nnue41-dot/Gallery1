import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Dimensions, Alert } from 'react-native';
import { Image } from 'expo-image';
import * as VideoThumbnails from 'expo-video-thumbnails';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { useThemeColors, useStyles } from '../theme';
import { listTrash, restoreItems, permanentDelete, daysLeft } from '../services/trash';
import { emitMediaChange } from '../services/mediaEvents';
import ConfirmDialog from '../components/ConfirmDialog';

const COLS = 3;
const GAP = 2;
const SIZE = (Dimensions.get('window').width - GAP * (COLS - 1)) / COLS;

function TrashThumb({ item }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const [uri, setUri] = useState(item.mediaType === 'video' ? null : item.trashUri);
  useEffect(() => {
    if (item.mediaType !== 'video') return undefined;
    let live = true;
    VideoThumbnails.getThumbnailAsync(item.trashUri, { time: 500 })
      .then((t) => { if (live) setUri(t.uri); })
      .catch(() => { /* placeholder */ });
    return () => { live = false; };
  }, [item.trashUri]);
  if (!uri) {
    return (
      <View style={styles.vid}><Ionicons name="videocam" size={18} color={colors.muted} /></View>
    );
  }
  return <Image source={{ uri }} style={styles.img} contentFit="cover" cachePolicy="memory-disk" recyclingKey={item.trashUri} />;
}

export default function TrashScreen() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [items, setItems] = useState([]);
  const [sel, setSel] = useState(() => new Set());
  const [confirm, setConfirm] = useState(null); // { list, empty }

  const refresh = useCallback(async () => setItems(await listTrash()), []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));

  const selected = items.filter((i) => sel.has(i.trashUri));
  const toggle = (k) => setSel((prev) => {
    const next = new Set(prev);
    if (next.has(k)) next.delete(k); else next.add(k);
    return next;
  });

  const run = async (fn, list) => {
    if (!list.length) return;
    try {
      await fn(list);
      emitMediaChange({ type: 'changed' });
    } catch {
      Alert.alert('خطأ', 'تعذرت العملية.');
    } finally {
      setSel(new Set());
      await refresh();
    }
  };

  return (
    <View style={styles.root}>
      <View style={[styles.bar, { paddingTop: insets.top + 8 }]}>
        <Pressable onPress={() => (sel.size ? setSel(new Set()) : navigation.goBack())} hitSlop={12}>
          <Ionicons name={sel.size ? 'close' : 'arrow-back'} size={24} color={colors.text} />
        </Pressable>
        <Text style={styles.title}>{sel.size ? `${sel.size} محدد` : 'سلة المحذوفات'}</Text>
        <View style={{ width: 24 }} />
      </View>

      {items.length === 0 ? (
        <Text style={styles.msg}>السلة فارغة. العناصر المحذوفة تبقى هنا 30 يوماً ثم تُحذف نهائياً.</Text>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(i) => i.trashUri}
          numColumns={COLS}
          columnWrapperStyle={{ gap: GAP }}
          contentContainerStyle={{ gap: GAP, paddingBottom: insets.bottom + 90 }}
          renderItem={({ item, index }) => {
            const on = sel.has(item.trashUri);
            return (
              <Pressable
                style={styles.tile}
                delayLongPress={250}
                onLongPress={() => toggle(item.trashUri)}
                onPress={() => {
                  if (sel.size) toggle(item.trashUri);
                  else navigation.navigate('TrashViewer', { items, index });
                }}
              >
                <TrashThumb item={item} />
                <View style={styles.days}><Text style={styles.daysText}>{daysLeft(item)} يوم</Text></View>
                {on && <View style={styles.sel}><Ionicons name="checkmark-circle" size={22} color={colors.accent} /></View>}
              </Pressable>
            );
          }}
        />
      )}

      {items.length > 0 && (
        <View style={[styles.bottom, { paddingBottom: insets.bottom + 12 }]}>
          {selected.length > 0 ? (
            <>
              <Pressable style={styles.btn} onPress={() => run(restoreItems, selected)}>
                <Text style={styles.btnText}>استعادة ({selected.length})</Text>
              </Pressable>
              <Pressable style={[styles.btn, styles.danger]} onPress={() => setConfirm({ list: selected, empty: false })}>
                <Text style={styles.btnText}>حذف نهائي</Text>
              </Pressable>
            </>
          ) : (
            <Pressable style={[styles.btn, styles.danger]} onPress={() => setConfirm({ list: items, empty: true })}>
              <Text style={styles.btnText}>إفراغ السلة</Text>
            </Pressable>
          )}
        </View>
      )}

      <ConfirmDialog
        visible={!!confirm}
        title={confirm?.empty ? 'إفراغ السلة' : 'حذف نهائي'}
        message="لا يمكن التراجع عن هذا الإجراء."
        confirmText="حذف نهائي"
        onCancel={() => setConfirm(null)}
        onConfirm={() => { const c = confirm; setConfirm(null); run(permanentDelete, c.list); }}
      />
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  bar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 10, backgroundColor: colors.surface },
  title: { color: colors.text, fontSize: 18, fontWeight: '700' },
  msg: { color: colors.muted, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
  tile: { width: SIZE, height: SIZE, backgroundColor: colors.surfaceAlt },
  img: { width: '100%', height: '100%' },
  vid: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  days: { position: 'absolute', left: 4, bottom: 4, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 4, paddingHorizontal: 4, paddingVertical: 1 },
  daysText: { color: '#fff', fontSize: 10 },
  sel: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(47,107,255,0.25)', alignItems: 'flex-end', padding: 4 },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', gap: 12, padding: 12, backgroundColor: colors.surface },
  btn: { flex: 1, backgroundColor: colors.accent, borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  danger: { backgroundColor: colors.danger },
  btnText: { color: '#fff', fontWeight: '700' },
});
