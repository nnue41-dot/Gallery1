import React, { useEffect, useRef, useState } from 'react';
import { View, Text, FlatList, Pressable, ActivityIndicator, StyleSheet, Dimensions } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import * as MediaLibrary from 'expo-media-library';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import * as Media from '../services/media';
import { prefetchFolders } from '../services/folderCache';
import { getThumb } from '../services/thumbs';
import { useApp, useStyles, useThemeColors } from '../theme';

const GAP = 8;
const SCREEN_W = Dimensions.get('window').width;
const yieldUI = () => new Promise((r) => setTimeout(r, 0));

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  header: { paddingHorizontal: 16, paddingBottom: 12 },
  title: { color: colors.text, fontSize: 20, fontWeight: '700' },
  msg: { color: colors.muted, textAlign: 'center', marginTop: 40, paddingHorizontal: 24 },
  row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  icon: { width: 44, height: 44, borderRadius: 10, backgroundColor: colors.surfaceAlt, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  name: { color: colors.text, fontSize: 16, fontWeight: '600' },
  count: { color: colors.muted, fontSize: 12, marginTop: 2 },
  card: { marginBottom: GAP },
  cover: { width: '100%', borderRadius: 12, backgroundColor: colors.surfaceAlt, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  coverImg: { width: '100%', height: '100%' },
  cardName: { color: colors.text, fontSize: 13, fontWeight: '600', marginTop: 6 },
  cardCount: { color: colors.muted, fontSize: 11, marginTop: 1 },
});

export default function FoldersScreen() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const { settings } = useApp();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const columns = settings.folderLayout === 'list' ? 1 : (Number(settings.folderLayout) || 1);
  const cardW = (SCREEN_W - 24 - GAP * (columns - 1)) / columns;

  const [albums, setAlbums] = useState(null);
  const [failed, setFailed] = useState(false);
  const [covers, setCovers] = useState({});
  const coversRef = useRef({});

  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const ok = await Media.ensurePermission();
        if (!ok) { if (live) setFailed(true); return; }
        const list = await Media.listAlbums();
        if (live) setAlbums(list);
        prefetchFolders(list);
      } catch {
        if (live) setFailed(true);
      }
    })();
    return () => { live = false; };
  }, []);

  // Covers are needed only for grid layouts. Each cover is a cached thumbnail.
  useEffect(() => {
    if (!albums || columns === 1) return undefined;
    let live = true;
    (async () => {
      for (const al of albums) {
        if (!live) return;
        if (coversRef.current[al.id]) continue;
        try {
          const p = await MediaLibrary.getAssetsAsync({
            album: al.id, first: 1, mediaType: ['photo', 'video'],
            sortBy: [[MediaLibrary.SortBy.creationTime, false]],
          });
          const c = p.assets[0];
          if (c) {
            const uri = await getThumb(c);
            if (live) {
              coversRef.current[al.id] = uri;
              setCovers((prev) => ({ ...prev, [al.id]: uri }));
            }
          }
        } catch { /* no cover for this folder */ }
        await yieldUI();
      }
    })();
    return () => { live = false; };
  }, [albums, columns]);

  const header = (
    <View>
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Text style={styles.title}>المجلدات</Text>
      </View>
      <Pressable style={styles.row} onPress={() => navigation.navigate('Trash')}>
        <View style={styles.icon}><Ionicons name="trash" size={24} color={colors.danger} /></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>سلة المحذوفات</Text>
          <Text style={styles.count}>استرجاع العناصر المحذوفة</Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={colors.muted} />
      </Pressable>
      {failed && <Text style={styles.msg}>يلزم منح صلاحية الوصول للصور والفيديو لعرض المجلدات.</Text>}
      {!albums && !failed && <ActivityIndicator style={{ marginTop: 40 }} color={colors.accent} />}
    </View>
  );

  const renderRow = ({ item }) => (
    <Pressable style={styles.row} onPress={() => navigation.navigate('Folder', { album: item })}>
      <View style={styles.icon}><Ionicons name="folder" size={24} color={colors.accent} /></View>
      <View style={{ flex: 1 }}>
        <Text style={styles.name} numberOfLines={1}>{item.title}</Text>
        <Text style={styles.count}>{item.assetCount} عنصر</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.muted} />
    </Pressable>
  );

  const renderCard = ({ item }) => (
    <Pressable style={[styles.card, { width: cardW }]} onPress={() => navigation.navigate('Folder', { album: item })}>
      <View style={[styles.cover, { height: cardW }]}>
        {covers[item.id]
          ? <Image source={{ uri: covers[item.id] }} style={styles.coverImg} contentFit="cover" cachePolicy="memory-disk" />
          : <Ionicons name="folder" size={36} color={colors.accent} />}
      </View>
      <Text style={styles.cardName} numberOfLines={1}>{item.title}</Text>
      <Text style={styles.cardCount}>{item.assetCount} عنصر</Text>
    </Pressable>
  );

  return (
    <View style={styles.root}>
      <FlatList
        key={`cols-${columns}`}
        data={albums ?? []}
        numColumns={columns}
        keyExtractor={(a) => a.id}
        extraData={covers}
        ListHeaderComponent={header}
        columnWrapperStyle={columns > 1 ? { gap: GAP, paddingHorizontal: 12 } : undefined}
        contentContainerStyle={{ paddingBottom: insets.bottom + 90 }}
        renderItem={columns === 1 ? renderRow : renderCard}
      />
    </View>
  );
}
