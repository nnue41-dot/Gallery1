import React, { useRef, useState } from 'react';
import { View, FlatList, Pressable, StyleSheet, Dimensions, Text, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import ZoomableImage from '../components/ZoomableImage';
import VideoPlayer from '../components/VideoPlayer';
import ConfirmDialog from '../components/ConfirmDialog';
import { restoreItems, permanentDelete, daysLeft } from '../services/trash';
import { emitMediaChange } from '../services/mediaEvents';
import { useThemeColors, useStyles } from '../theme';

const { width } = Dimensions.get('window');
const noop = () => {};

export default function TrashViewer() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const { params } = useRoute();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();
  const [list, setList] = useState(params?.items ?? []);
  const [index, setIndex] = useState(params?.index ?? 0);
  const [showUI, setShowUI] = useState(true);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const cur = list[index];

  const onViewable = useRef(({ viewableItems }) => {
    const f = viewableItems[0];
    if (f && typeof f.index === 'number') setIndex(f.index);
  }).current;

  const removeCurrent = () => {
    const next = list.filter((x) => x.trashUri !== cur.trashUri);
    if (!next.length) { navigation.goBack(); return; }
    setList(next);
    setIndex(Math.min(index, next.length - 1));
  };

  const restore = async () => {
    if (!cur || busy) return;
    setBusy(true);
    try {
      const n = await restoreItems([cur]);
      if (n) {
        emitMediaChange({ type: 'changed' });
        removeCurrent();
      } else {
        Alert.alert('تعذرت الاستعادة', 'لم يتم نقل العنصر إلى المعرض.');
      }
    } catch {
      Alert.alert('خطأ', 'تعذرت الاستعادة.');
    } finally {
      setBusy(false);
    }
  };

  const destroy = async () => {
    if (!cur) return;
    try {
      await permanentDelete([cur]);
      removeCurrent();
    } catch {
      Alert.alert('خطأ', 'تعذر الحذف النهائي.');
    }
  };

  if (!cur) return <View style={styles.root} />;

  return (
    <View style={styles.root}>
      <FlatList
        data={list}
        horizontal
        pagingEnabled
        keyExtractor={(i) => i.trashUri}
        initialScrollIndex={index}
        getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
        showsHorizontalScrollIndicator={false}
        onViewableItemsChanged={onViewable}
        viewabilityConfig={{ itemVisiblePercentThreshold: 60 }}
        initialNumToRender={1}
        windowSize={3}
        extraData={[index, showUI]}
        renderItem={({ item, index: i }) => (
          <View style={styles.slide}>
            {item.mediaType === 'video' ? (
              <VideoPlayer
                uri={item.trashUri}
                active={i === index}
                showControls={showUI}
                onTap={() => setShowUI((v) => !v)}
                bottomInset={insets.bottom + 80}
              />
            ) : (
              <ZoomableImage
                uri={item.trashUri}
                active={i === index}
                zoomed={false}
                onZoomChange={noop}
                onSingleTap={() => setShowUI((v) => !v)}
              />
            )}
          </View>
        )}
      />

      {showUI && (
        <View style={[styles.top, { paddingTop: insets.top + 8 }]}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
            <Ionicons name="arrow-back" size={26} color="#fff" />
          </Pressable>
          <Text style={styles.title} numberOfLines={1}>{cur.filename}</Text>
          <Text style={styles.days}>{daysLeft(cur)} يوم</Text>
        </View>
      )}

      {showUI && (
        <View style={[styles.bottom, { paddingBottom: insets.bottom + 12 }]}>
          <Pressable style={styles.btn} onPress={restore} disabled={busy}>
            <Text style={styles.btnText}>استعادة</Text>
          </Pressable>
          <Pressable style={[styles.btn, styles.danger]} onPress={() => setConfirm(true)} disabled={busy}>
            <Text style={styles.btnText}>حذف نهائي</Text>
          </Pressable>
        </View>
      )}

      <ConfirmDialog
        visible={confirm}
        title="حذف نهائي"
        message="سيُحذف هذا العنصر نهائياً ولا يمكن استرجاعه."
        confirmText="حذف نهائي"
        onCancel={() => setConfirm(false)}
        onConfirm={() => { setConfirm(false); destroy(); }}
      />
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  slide: { width, flex: 1, backgroundColor: '#000' },
  top: { position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingBottom: 10, backgroundColor: 'rgba(0,0,0,0.5)' },
  title: { color: '#fff', fontSize: 15, fontWeight: '600', flex: 1 },
  days: { color: '#fff', fontSize: 12 },
  bottom: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', gap: 12, padding: 12, backgroundColor: 'rgba(0,0,0,0.6)' },
  btn: { flex: 1, backgroundColor: colors.accent, borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
  danger: { backgroundColor: colors.danger },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
});
