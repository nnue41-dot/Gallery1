// Full-screen media viewer, rebuilt with a small, predictable structure:
// - PagerView (native pager) for swiping; offscreenPageLimit=1 keeps only neighbours mounted.
// - PhotoPage: pinch zoom, double-tap zoom, pan when zoomed (react-native-gesture-handler + reanimated).
// - VideoPage: expo-video with a poster that fades out after the first frame; progress bar; skip; mute.
// - Actions: delete (trash), favorite, rotate, crop, info, share.
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Dimensions, Alert, ActivityIndicator, Modal, PanResponder, Animated } from 'react-native';
import PagerView from 'react-native-pager-view';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Reanimated, { useSharedValue, useAnimatedStyle, withTiming, runOnJS } from 'react-native-reanimated';
import { Image } from 'expo-image';
import { useVideoPlayer, VideoView } from 'expo-video';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import * as MediaLibrary from 'expo-media-library';
import * as ImageManipulator from 'expo-image-manipulator';
import * as FileSystem from 'expo-file-system';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import CropSheet from '../components/CropSheet';
import ConfirmDialog from '../components/ConfirmDialog';
import * as Media from '../services/media';
import { moveToTrash, showDeleteFailure } from '../services/trash';
import { shareAssets } from '../services/share';
import { loadFavorites, saveFavorites } from '../services/favorites';
import { emitMediaChange } from '../services/mediaEvents';
import { cachedThumb, getThumb } from '../services/thumbs';

const SW = Dimensions.get('window').width;
const SH = Dimensions.get('window').height;
const DANGER = '#B3262E';
const ACCENT = '#2F6BFF';

const cl = (v, lo, hi) => { 'worklet'; return Math.min(hi, Math.max(lo, v)); };
const fmt = (sec = 0) => {
  const s = Math.floor(sec || 0);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

function useLocalUri(asset) {
  const [uri, setUri] = useState(null);
  useEffect(() => {
    let live = true;
    Media.resolveLocalUri(asset).then((u) => { if (live) setUri(u); });
    return () => { live = false; };
  }, [asset.id]);
  return uri;
}

function usePoster(asset) {
  const [poster, setPoster] = useState(() => cachedThumb(asset));
  useEffect(() => {
    if (poster) return undefined;
    let live = true;
    getThumb(asset).then((u) => { if (live) setPoster(u); }).catch(() => {});
    return () => { live = false; };
  }, [asset.id]);
  return poster;
}

// ---------- photo ----------
function PhotoPage({ uri, poster, active, zoomed, onZoom, onTap, w, h }) {
  const scale = useSharedValue(1);
  const saved = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const stx = useSharedValue(0);
  const sty = useSharedValue(0);
  const maxX = (s) => { 'worklet'; return (w * (s - 1)) / 2; };
  const maxY = (s) => { 'worklet'; return (h * (s - 1)) / 2; };

  // Leaving the page resets its zoom (the parent resets its own zoomed flag on page change).
  useEffect(() => {
    if (!active) {
      scale.value = 1; saved.value = 1; tx.value = 0; ty.value = 0; stx.value = 0; sty.value = 0;
    }
  }, [active]);

  const pinch = Gesture.Pinch()
    .onUpdate((e) => {
      const s = cl(saved.value * e.scale, 1, 5);
      scale.value = s;
      tx.value = cl(stx.value, -maxX(s), maxX(s));
      ty.value = cl(sty.value, -maxY(s), maxY(s));
    })
    .onEnd(() => {
      if (scale.value <= 1.05) {
        scale.value = withTiming(1); tx.value = withTiming(0); ty.value = withTiming(0);
        saved.value = 1; stx.value = 0; sty.value = 0;
        runOnJS(onZoom)(false);
      } else {
        saved.value = scale.value; stx.value = tx.value; sty.value = ty.value;
        runOnJS(onZoom)(true);
      }
    });

  const pan = Gesture.Pan()
    .enabled(zoomed)
    .onUpdate((e) => {
      tx.value = cl(stx.value + e.translationX, -maxX(scale.value), maxX(scale.value));
      ty.value = cl(sty.value + e.translationY, -maxY(scale.value), maxY(scale.value));
    })
    .onEnd(() => { stx.value = tx.value; sty.value = ty.value; });

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .maxDuration(260)
    .onEnd((e) => {
      if (scale.value > 1.01) {
        scale.value = withTiming(1); tx.value = withTiming(0); ty.value = withTiming(0);
        saved.value = 1; stx.value = 0; sty.value = 0;
        runOnJS(onZoom)(false);
      } else {
        const s = 2.5;
        const nx = cl(-(e.x - w / 2) * (s - 1), -maxX(s), maxX(s));
        const ny = cl(-(e.y - h / 2) * (s - 1), -maxY(s), maxY(s));
        scale.value = withTiming(s); tx.value = withTiming(nx); ty.value = withTiming(ny);
        saved.value = s; stx.value = nx; sty.value = ny;
        runOnJS(onZoom)(true);
      }
    });

  const singleTap = Gesture.Tap()
    .maxDuration(250)
    .onEnd((_e, ok) => { if (ok) runOnJS(onTap)(); });

  const gesture = Gesture.Simultaneous(pinch, pan, Gesture.Exclusive(doubleTap, singleTap));
  const animated = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
  }));

  const src = uri || poster;
  return (
    <View style={{ width: w, height: h, backgroundColor: '#000' }}>
      <GestureDetector gesture={gesture}>
        <Reanimated.View style={[{ width: w, height: h }, animated]}>
          {src ? <Image source={{ uri: src }} style={{ width: w, height: h }} contentFit="contain" /> : null}
        </Reanimated.View>
      </GestureDetector>
    </View>
  );
}

// ---------- video ----------
function VideoPage({ uri, poster, active, showUI, onTap, bgAudio, w, h, bottomInset }) {
  const player = useVideoPlayer(uri, (p) => { p.loop = false; });
  const playerRef = useRef(player);
  playerRef.current = player;

  const [ready, setReady] = useState(false);
  const fade = useRef(new Animated.Value(1)).current;
  const [st, setSt] = useState({ pos: 0, dur: 0, playing: false, ended: false });
  const [muted, setMuted] = useState(false);
  const [scrub, setScrub] = useState(null);
  const trackW = useRef(1);
  const durRef = useRef(0);
  durRef.current = st.dur;

  useEffect(() => { setReady(false); fade.setValue(1); }, [uri, fade]);
  useEffect(() => {
    if (!ready) return;
    Animated.timing(fade, { toValue: 0, duration: 180, useNativeDriver: true }).start();
  }, [ready, fade]);

  useEffect(() => { if (active) player.play(); else player.pause(); }, [active, player]);
  useEffect(() => { player.muted = muted; }, [muted, player]);
  useEffect(() => { player.allowsBackgroundPlayback = !!bgAudio; }, [bgAudio, player]);

  // Progress is polled only for the visible video.
  useEffect(() => {
    if (!active) return undefined;
    const id = setInterval(() => {
      setSt((prev) => ({
        pos: player.currentTime || 0,
        dur: player.duration || 0,
        playing: player.playing,
        ended: prev.ended && !player.playing,
      }));
    }, 250);
    const sub = player.addListener('playToEnd', () => setSt((p) => ({ ...p, ended: true, playing: false })));
    return () => { clearInterval(id); sub.remove(); };
  }, [player, active]);

  const seekTo = (sec) => {
    const p = playerRef.current;
    p.currentTime = Math.max(0, Math.min(sec, durRef.current || 0));
  };
  const togglePlay = () => {
    const p = playerRef.current;
    if (st.ended) { p.currentTime = 0; p.play(); return; }
    if (p.playing) p.pause(); else p.play();
  };

  const pctOf = (x) => Math.max(0, Math.min(1, x / trackW.current));
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onStartShouldSetPanResponderCapture: () => true,
    onMoveShouldSetPanResponderCapture: () => true,
    onPanResponderGrant: (e) => setScrub(pctOf(e.nativeEvent.locationX)),
    onPanResponderMove: (e) => setScrub(pctOf(e.nativeEvent.locationX)),
    onPanResponderRelease: (e) => {
      const p = pctOf(e.nativeEvent.locationX);
      setScrub(null);
      seekTo(p * durRef.current);
    },
    onPanResponderTerminate: () => setScrub(null),
  })).current;

  const pct = scrub ?? (st.dur ? st.pos / st.dur : 0);
  const shown = scrub !== null ? scrub * st.dur : st.pos;

  return (
    <View style={{ width: w, height: h, backgroundColor: '#000' }}>
      <Pressable style={StyleSheet.absoluteFill} onPress={onTap}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          contentFit="contain"
          nativeControls={false}
          onFirstFrameRender={() => setReady(true)}
        />
      </Pressable>
      {poster ? (
        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { opacity: fade }]}>
          <Image source={{ uri: poster }} style={StyleSheet.absoluteFill} contentFit="contain" />
        </Animated.View>
      ) : null}

      {active && showUI && (
        <>
          <View style={styles.center} pointerEvents="box-none">
            <Pressable onPress={togglePlay} style={styles.big} hitSlop={10}>
              <Ionicons name={st.ended ? 'reload' : st.playing ? 'pause' : 'play'} size={40} color="#fff" />
            </Pressable>
          </View>
          <View style={[styles.bottomBox, { bottom: bottomInset }]}>
            <Text style={styles.time}>{fmt(shown)} / {fmt(st.dur)}</Text>
            <View
              style={styles.track}
              onLayout={(e) => { trackW.current = e.nativeEvent.layout.width; }}
              {...pan.panHandlers}
            >
              <View style={styles.trackBg} pointerEvents="none" />
              <View style={[styles.fill, { width: `${pct * 100}%` }]} pointerEvents="none" />
              <View style={[styles.knob, { left: `${pct * 100}%` }]} pointerEvents="none" />
            </View>
            <View style={styles.row}>
              <Pressable onPress={() => seekTo((playerRef.current.currentTime || 0) - 10)} hitSlop={8}>
                <Ionicons name="play-back" size={22} color="#fff" />
              </Pressable>
              <Pressable onPress={togglePlay} hitSlop={8}>
                <Ionicons name={st.playing ? 'pause' : 'play'} size={24} color="#fff" />
              </Pressable>
              <Pressable onPress={() => seekTo((playerRef.current.currentTime || 0) + 10)} hitSlop={8}>
                <Ionicons name="play-forward" size={22} color="#fff" />
              </Pressable>
              <Pressable onPress={() => setMuted((m) => !m)} hitSlop={8}>
                <Ionicons name={muted ? 'volume-mute' : 'volume-high'} size={22} color="#fff" />
              </Pressable>
            </View>
          </View>
        </>
      )}
    </View>
  );
}

// Chooses the right page for an asset and loads its file and poster.
function Page(props) {
  const { asset } = props;
  const uri = useLocalUri(asset);
  const poster = usePoster(asset);
  if (asset.mediaType === 'video') {
    if (!uri) {
      return (
        <View style={{ width: props.w, height: props.h, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' }}>
          {poster ? <Image source={{ uri: poster }} style={StyleSheet.absoluteFill} contentFit="contain" /> : <ActivityIndicator color="#fff" />}
        </View>
      );
    }
    return <VideoPage uri={uri} poster={poster} {...props} />;
  }
  return <PhotoPage uri={uri} poster={poster} {...props} />;
}

// ---------- screen ----------
export default function ViewerScreen() {
  const { params } = useRoute();
  const navigation = useNavigation();
  const insets = useSafeAreaInsets();

  const [list, setList] = useState(() => params?.assets ?? []);
  const [index, setIndex] = useState(() => Math.max(0, Math.min(params?.index ?? 0, (params?.assets ?? []).length - 1)));
  const [showUI, setShowUI] = useState(true);
  const [zoomed, setZoomed] = useState(false);
  const [bgAudio, setBgAudio] = useState(false);
  const [favs, setFavs] = useState(() => new Set());
  const [confirmDel, setConfirmDel] = useState(false);
  const [info, setInfo] = useState(null);
  const [cropOpen, setCropOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [box, setBox] = useState({ w: SW, h: SH });
  const pagerRef = useRef(null);
  const cur = list[index];

  useEffect(() => { loadFavorites().then(setFavs); }, []);

  const toggleUI = useCallback(() => setShowUI((v) => !v), []);
  const onZoom = useCallback((z) => setZoomed(z), []);
  const onPageSelected = (e) => {
    setIndex(e.nativeEvent.position);
    setZoomed(false);
  };

  const insertCopy = (copy) => {
    setList((prev) => {
      const i = prev.findIndex((a) => a.id === cur.id);
      return [...prev.slice(0, i + 1), copy, ...prev.slice(i + 1)];
    });
    emitMediaChange({ type: 'changed' });
  };

  const favorite = async () => {
    const next = new Set(favs);
    if (next.has(cur.id)) next.delete(cur.id); else next.add(cur.id);
    setFavs(next);
    await saveFavorites(next);
    emitMediaChange({ type: 'favorites' });
  };

  const share = () => {
    shareAssets([cur], () => {}).catch(() => Alert.alert('خطأ', 'تعذرت المشاركة.'));
  };

  const rotate = async () => {
    if (cur.mediaType === 'video') return;
    setBusy(true);
    try {
      const local = await Media.resolveLocalUri(cur);
      const out = await ImageManipulator.manipulateAsync(local, [{ rotate: 90 }], {
        compress: 0.95, format: ImageManipulator.SaveFormat.JPEG,
      });
      insertCopy(await MediaLibrary.createAssetAsync(out.uri));
    } catch {
      Alert.alert('خطأ', 'تعذر تدوير الصورة.');
    } finally {
      setBusy(false);
    }
  };

  const doRemove = async () => {
    try {
      const ok = await moveToTrash([cur], null);
      if (!ok) { showDeleteFailure(); return; }
      emitMediaChange({ type: 'deleted', ids: [cur.id] });
      const next = list.filter((a) => a.id !== cur.id);
      if (next.length === 0) { navigation.goBack(); return; }
      const ni = Math.min(index, next.length - 1);
      setList(next);
      setIndex(ni);
      setTimeout(() => pagerRef.current?.setPageWithoutAnimation(ni), 0);
    } catch {
      Alert.alert('خطأ', 'تعذر الحذف.');
    }
  };

  const openInfo = async () => {
    try {
      const local = await Media.resolveLocalUri(cur);
      let full = {};
      try { full = (await MediaLibrary.getAssetInfoAsync(cur)) || {}; } catch { /* optional */ }
      let size = null;
      try {
        const i = await FileSystem.getInfoAsync(local);
        size = i.exists ? i.size : null;
      } catch { /* optional */ }
      const raw = full.creationTime || full.modificationTime || cur.creationTime || cur.modificationTime || 0;
      const ms = raw && raw < 1e12 ? raw * 1000 : raw;
      const path = decodeURIComponent((full.localUri || local || '').replace(/^file:\/\//, ''));
      setInfo({
        ...cur,
        size,
        path: path || null,
        date: ms ? new Date(ms).toLocaleString() : null,
        folderTitle: params?.folderTitle ?? null,
      });
    } catch {
      Alert.alert('خطأ', 'تعذر قراءة المعلومات.');
    }
  };

  if (!cur) return <View style={styles.root} />;
  const isVideo = cur.mediaType === 'video';
  const isFav = favs.has(cur.id);
  const action = (icon, label, onPress, danger) => (
    <Pressable key={label} style={styles.action} onPress={onPress} hitSlop={6}>
      <Ionicons name={icon} size={22} color={danger ? DANGER : '#fff'} />
      <Text style={styles.actionTxt}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={styles.root} onLayout={(e) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}>
      <StatusBar style="light" />
      <PagerView
        ref={pagerRef}
        style={StyleSheet.absoluteFill}
        initialPage={index}
        offscreenPageLimit={1}
        scrollEnabled={!zoomed}
        onPageSelected={onPageSelected}
      >
        {list.map((a, i) => (
          <View key={a.id} style={{ flex: 1 }}>
            <Page
              asset={a}
              active={i === index}
              zoomed={zoomed && i === index}
              onZoom={onZoom}
              onTap={toggleUI}
              showUI={showUI}
              bgAudio={bgAudio && i === index}
              bottomInset={insets.bottom + 72}
              w={box.w}
              h={box.h}
            />
          </View>
        ))}
      </PagerView>

      {showUI && (
        <View style={[styles.top, { paddingTop: insets.top + 8 }]}>
          <Pressable onPress={() => navigation.goBack()} hitSlop={12}>
            <Ionicons name="arrow-back" size={26} color="#fff" />
          </Pressable>
          <Text style={styles.title} numberOfLines={1}>{cur.filename}</Text>
          <Text style={styles.counter}>{index + 1}/{list.length}</Text>
          {isVideo ? (
            <Pressable onPress={() => setBgAudio((v) => !v)} hitSlop={12}>
              <Ionicons name={bgAudio ? 'headset' : 'headset-outline'} size={22} color={bgAudio ? ACCENT : '#fff'} />
            </Pressable>
          ) : (
            <Pressable onPress={() => setCropOpen(true)} hitSlop={12}>
              <Ionicons name="cut-outline" size={22} color="#fff" />
            </Pressable>
          )}
        </View>
      )}

      {showUI && (
        <View style={[styles.bottom, { paddingBottom: insets.bottom + 8 }]}>
          {action('trash-outline', 'حذف', () => setConfirmDel(true), true)}
          {!isVideo && action('color-wand-outline', 'تدوير', rotate)}
          {action(isFav ? 'heart' : 'heart-outline', 'مفضلة', favorite, isFav)}
          {action('information-circle-outline', 'معلومات', openInfo)}
          {action('share-social-outline', 'مشاركة', share)}
        </View>
      )}

      <ConfirmDialog
        visible={confirmDel}
        title="حذف"
        message="نقل هذا العنصر إلى السلة؟ يمكن استرجاعه خلال 30 يوماً."
        confirmText="حذف"
        onCancel={() => setConfirmDel(false)}
        onConfirm={() => { setConfirmDel(false); doRemove(); }}
      />

      <CropSheet visible={cropOpen} asset={cur} onClose={() => setCropOpen(false)} onSaved={insertCopy} />

      <Modal visible={!!info} transparent animationType="fade" onRequestClose={() => setInfo(null)}>
        <Pressable style={styles.scrim} onPress={() => setInfo(null)}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>المعلومات</Text>
            <Text style={styles.cardRow}>الاسم: {info?.filename}</Text>
            <Text style={styles.cardRow}>المجلد: {info?.folderTitle ?? '—'}</Text>
            <Text style={styles.cardRow}>المسار: {info?.path ?? '—'}</Text>
            <Text style={styles.cardRow}>التاريخ: {info?.date ?? '—'}</Text>
            <Text style={styles.cardRow}>الأبعاد: {info?.width} × {info?.height}</Text>
            {info?.mediaType === 'video' && <Text style={styles.cardRow}>المدة: {Math.round(info?.duration ?? 0)} ث</Text>}
            <Text style={styles.cardRow}>الحجم: {info?.size ? `${(info.size / 1048576).toFixed(2)} MB` : '—'}</Text>
          </View>
        </Pressable>
      </Modal>

      {busy && (
        <View style={styles.busy}><ActivityIndicator color="#fff" size="large" /></View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  top: {
    position: 'absolute', top: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'center',
    gap: 14, paddingHorizontal: 16, paddingBottom: 10, backgroundColor: 'rgba(0,0,0,0.5)',
  },
  title: { color: '#fff', fontSize: 15, fontWeight: '600', flex: 1 },
  counter: { color: '#fff', fontSize: 13 },
  bottom: {
    position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', justifyContent: 'space-around',
    paddingTop: 12, backgroundColor: 'rgba(0,0,0,0.5)',
  },
  action: { alignItems: 'center', gap: 4, minWidth: 56 },
  actionTxt: { color: '#fff', fontSize: 11 },
  center: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  big: { backgroundColor: 'rgba(0,0,0,0.45)', borderRadius: 40, padding: 14 },
  bottomBox: { position: 'absolute', left: 0, right: 0, paddingHorizontal: 16 },
  time: { color: '#fff', fontSize: 12, marginBottom: 4 },
  track: { height: 28, justifyContent: 'center' },
  trackBg: { position: 'absolute', left: 0, right: 0, height: 3, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 2 },
  fill: { position: 'absolute', left: 0, height: 3, backgroundColor: ACCENT, borderRadius: 2 },
  knob: { position: 'absolute', width: 14, height: 14, borderRadius: 7, backgroundColor: '#fff', top: 7, marginLeft: -7 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 4, paddingHorizontal: 8 },
  busy: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' },
  scrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 },
  card: { backgroundColor: '#121A2B', borderRadius: 14, padding: 20, gap: 10, borderWidth: 1, borderColor: '#1C2A44' },
  cardTitle: { color: '#E8EDF7', fontSize: 17, fontWeight: '700' },
  cardRow: { color: '#E8EDF7', fontSize: 14 },
});
