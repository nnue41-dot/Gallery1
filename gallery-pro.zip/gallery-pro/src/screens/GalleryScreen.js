import React, { useCallback, useEffect, useMemo, useRef, useState, startTransition } from 'react';
import { View, Text, FlatList, Pressable, Modal, StyleSheet, Alert, ActivityIndicator, BackHandler, Dimensions, RefreshControl, InteractionManager, TextInput, Animated } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import * as VideoThumbnails from 'expo-video-thumbnails';
import { useThemeColors, useStyles } from '../theme';
import * as Media from '../services/media';
import { loadFavorites, saveFavorites } from '../services/favorites';
import { onMediaChange } from '../services/mediaEvents';
import { moveToTrash, showDeleteFailure } from '../services/trash';
import DateScrubber from '../components/DateScrubber';
import ConfirmDialog from '../components/ConfirmDialog';
import { startProgress, endProgress, tickProgress } from '../services/progress';
import { shareAssets } from '../services/share';
import { getThumb, thumbKey, cachedThumb } from '../services/thumbs';
import { readLibCache, writeLibCache, getScanCount, setScanCount } from '../services/libcache';
import * as FileSystemInfo from 'expo-file-system';

const COLS = 3;
const GAP = 2;
const SIZE = (Dimensions.get('window').width - GAP * (COLS - 1)) / COLS;
const fmt = (s = 0) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

// Date: normalize creationTime (ms or seconds) with fallbacks so no item lands at the bottom by mistake.
const tsOf = (a) => {
  const v = a.creationTime || a.modificationTime || 0;
  return v && v < 1e12 ? v * 1000 : v;
};

function Thumb({ asset }) {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const key = thumbKey(asset);
  const [uri, setUri] = useState(() => cachedThumb(asset));
  const fade = useRef(new Animated.Value(uri ? 1 : 0)).current;

  // Only mounted (visible) tiles request a thumbnail, so the visible ones come first.
  useEffect(() => {
    if (uri) return undefined;
    let live = true;
    getThumb(asset).then((u) => { if (live) setUri(u); }).catch(() => { /* keep placeholder */ });
    return () => { live = false; };
  }, [key]);

  useEffect(() => {
    if (!uri) return;
    Animated.timing(fade, { toValue: 1, duration: 240, useNativeDriver: true }).start();
  }, [uri, fade]);

  return (
    <View style={[styles.img, { overflow: 'hidden' }]}>
      <View style={[StyleSheet.absoluteFill, styles.videoTile]}>
        <Ionicons name={asset.mediaType === 'video' ? 'videocam' : 'image-outline'} size={18} color={colors.muted} />
      </View>
      {uri && (
        <Animated.View style={[StyleSheet.absoluteFill, { opacity: fade }]}>
          <Image source={{ uri }} style={styles.img} contentFit="cover" cachePolicy="memory-disk" recyclingKey={key} />
        </Animated.View>
      )}
    </View>
  );
}

const SORTS = [
  { key: 'date-desc', label: 'الأحدث أولاً' },
  { key: 'date-asc', label: 'الأقدم أولاً' },
  { key: 'size-desc', label: 'الأكبر حجماً' },
  { key: 'size-asc', label: 'الأصغر حجماً' },
];

export default function GalleryScreen() {
  const colors = useThemeColors();
  const styles = useStyles(makeStyles);
  const navigation = useNavigation();
  const route = useRoute();
  const album = route.params?.album;
  const favoritesOnly = !!route.params?.favoritesOnly; // undefined on the main Photos tab
  const insets = useSafeAreaInsets();
  const mounted = useRef(true);

  const [permitted, setPermitted] = useState(null);
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(() => new Set());
  const [favorites, setFavorites] = useState(() => new Set());
  const [menuOpen, setMenuOpen] = useState(false);
  const [pickerMode, setPickerMode] = useState(null); // 'copy' | 'move' | null
  const [albums, setAlbums] = useState([]);
  const [busy, setBusy] = useState(false);
  const [sortMode, setSortMode] = useState('date-desc');
  const [mediaFilter, setMediaFilter] = useState(null); // 'photo' | 'video' | null
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const listRef = useRef(null);
  const pressTimer = useRef(null);
  const longFired = useRef(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const scrollAnim = useRef(new Animated.Value(0)).current;
  const [scrollLabel, setScrollLabel] = useState(null);
  const [showScrub, setShowScrub] = useState(false);
  const contentH = useRef(1);
  const viewH = useRef(1);
  const hideT = useRef(null);
  const sectionsRef = useRef([]);
  const [sortOpen, setSortOpen] = useState(false);
  const [sizes, setSizes] = useState({});

  const selecting = selected.size > 0;
  const selectedAssets = useMemo(() => assets.filter((a) => selected.has(a.id)), [assets, selected]);

  // Date order is computed once per library scan; tabs and favorites only filter it.
  const dateDesc = useMemo(() => assets
    .map((x) => ({ x, t: tsOf(x) }))
    .sort((p, q) => (q.t - p.t) || (p.x.id < q.x.id ? -1 : 1))
    .map((p) => p.x), [assets]);
  const dateAsc = useMemo(() => dateDesc.slice().reverse(), [dateDesc]);
  const sizeSorted = useMemo(() => {
    if (!sortMode.startsWith('size')) return null;
    const m = sortMode === 'size-asc' ? 1 : -1;
    return assets.slice().sort((p, q) => m * ((sizes[p.id] ?? 0) - (sizes[q.id] ?? 0)));
  }, [assets, sortMode, sizes]);

  const sorted = useMemo(() => {
    let arr = sortMode === 'date-desc' ? dateDesc : sortMode === 'date-asc' ? dateAsc : sizeSorted;
    if (favoritesOnly) arr = arr.filter((x) => favorites.has(x.id));
    if (mediaFilter) arr = arr.filter((x) => x.mediaType === mediaFilter);
    const q = query.trim().toLowerCase();
    if (q) arr = arr.filter((x) => (x.filename || '').toLowerCase().includes(q));
    return arr;
  }, [dateDesc, dateAsc, sizeSorted, sortMode, favorites, favoritesOnly, mediaFilter, query]);
  const sortedRef = useRef(sorted);
  sortedRef.current = sorted;

  const sections = useMemo(() => {
    const out = [];
    let last = null;
    sorted.forEach((a, i) => {
      const d = new Date(tsOf(a));
      const k = `${d.getFullYear()}-${d.getMonth()}`;
      if (k !== last) {
        out.push({ key: k, label: `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}`, index: i });
        last = k;
      }
    });
    return out;
  }, [sorted]);
  sectionsRef.current = sections;

  useEffect(() => {
    mounted.current = true;
    loadFavorites().then((s) => { if (mounted.current) setFavorites(s); });
    return () => { mounted.current = false; };
  }, []);

  const load = useCallback(async () => {
    const cacheKey = `gallerypro:lib:${album?.id ?? 'all'}`;
    setLoading(true);
    try {
      const ok = await Media.ensurePermission();
      if (!mounted.current) return;
      setPermitted(ok);
      if (!ok) return;
      const cached = await readLibCache(cacheKey);
      if (cached.length && mounted.current) setAssets(cached);
      if (album && cached.length && (cached.length === album.assetCount || getScanCount(cacheKey) === album.assetCount)) {
        return;
      }
      const fresh = [];
      let flushT = null;
      let lastWrite = 0;
      const flush = () => {
        flushT = null;
        if (mounted.current) setAssets(fresh.slice());
        if (!cached.length && fresh.length - lastWrite >= 3000) {
          lastWrite = fresh.length;
          writeLibCache(cacheKey, fresh.slice());
        }
      };
      await Media.listAssets({
        albumId: album?.id,
        onChunk: (chunk) => {
          fresh.push(...chunk);
          // Without a cache, show progress at most once per second; never per page.
          if (!cached.length && !flushT) flushT = setTimeout(flush, 250);
        },
      });
      if (flushT) clearTimeout(flushT);
      if (mounted.current) setAssets(fresh);
      writeLibCache(cacheKey, fresh);
      if (album) setScanCount(cacheKey, album.assetCount);
    } catch {
      if (mounted.current) Alert.alert('Error', 'Could not load media.');
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, [album?.id]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => onMediaChange((ev) => {
    if (!mounted.current) return;
    if (ev.type === 'deleted') setAssets((prev) => prev.filter((a) => !ev.ids.includes(a.id)));
    else if (ev.type === 'favorites') loadFavorites().then((s) => { if (mounted.current) setFavorites(s); });
    else if (ev.type === 'changed') load();
  }), [load]);

  // Size sorting reads file sizes in small batches, yielding between batches so scrolling stays smooth.
  useEffect(() => {
    if (!sortMode.startsWith('size')) return undefined;
    let cancelled = false;
    (async () => {
      const todo = assets.filter((a) => sizes[a.id] === undefined);
      for (let i = 0; i < todo.length && !cancelled; i += 40) {
        const batch = todo.slice(i, i + 40);
        const entries = await Promise.all(batch.map(async (a) => {
          try {
            const info = await FileSystemInfo.getInfoAsync(await Media.resolveLocalUri(a));
            return [a.id, info.exists ? info.size : 0];
          } catch {
            return [a.id, 0];
          }
        }));
        if (cancelled || !mounted.current) return;
        setSizes((prev) => {
          const next = { ...prev };
          entries.forEach(([id, sz]) => { next[id] = sz; });
          return next;
        });
        await new Promise((r) => setTimeout(r, 0));
      }
    })();
    return () => { cancelled = true; };
  }, [sortMode, assets]);

  // Hardware back clears selection first instead of leaving the screen.
  useFocusEffect(useCallback(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (selected.size) { setSelected(new Set()); return true; }
      return false;
    });
    return () => sub.remove();
  }, [selected]));

  const onScrollList = useCallback((e) => {
    const { contentOffset, contentSize, layoutMeasurement } = e.nativeEvent;
    const max = Math.max(1, contentSize.height - layoutMeasurement.height);
    scrollAnim.setValue(Math.min(1, contentOffset.y / max));
    const itemIdx = Math.floor(contentOffset.y / (SIZE + GAP)) * COLS;
    let lbl = null;
    for (const s of sectionsRef.current) {
      if (s.index <= itemIdx) lbl = s.label; else break;
    }
    setScrollLabel(lbl);
    setShowScrub(true);
    clearTimeout(hideT.current);
    hideT.current = setTimeout(() => setShowScrub(false), 1200);
  }, []);

  const dragTo = useCallback((f) => {
    const max = Math.max(0, contentH.current - viewH.current);
    listRef.current?.scrollToOffset({ offset: f * max, animated: false });
    scrollAnim.setValue(f);
  }, []);

  const clearSel = () => { setSelected(new Set()); setMenuOpen(false); };
  const toggle = (id) => setSelected((prev) => {
    const next = new Set(prev);
    next.has(id) ? next.delete(id) : next.add(id);
    return next;
  });

  const removeFavorites = async () => {
    const next = new Set(favorites);
    selectedAssets.forEach((x) => next.delete(x.id));
    setFavorites(next);
    await saveFavorites(next);
    emitMediaChange({ type: 'favorites' });
    clearSel();
    setMenuOpen(false);
  };

  const shareSelected = async () => {
    const target = selectedAssets;
    if (!target.length) return;
    startProgress('تجهيز المشاركة', target.length);
    try {
      await shareAssets(target, () => tickProgress(1));
    } catch {
      Alert.alert('خطأ', 'تعذرت المشاركة.');
    } finally {
      endProgress();
    }
  };

  const addFavorites = async () => {
    const next = new Set(favorites);
    selectedAssets.forEach((a) => next.add(a.id));
    setFavorites(next);
    await saveFavorites(next);
    clearSel();
  };

  const doDelete = () => { setMenuOpen(false); setConfirmDel(true); };

  const runDelete = async () => {
    setMenuOpen(false);
    const target = selectedAssets;
    if (!target.length) return;
    setBusy(true);
    try {
      const ok = await moveToTrash(target, album?.title ?? null);
      clearSel();
      if (ok) setAssets((prev) => prev.filter((a) => !target.some((t) => t.id === a.id)));
      else showDeleteFailure();
    } catch {
      Alert.alert('خطأ', 'تعذر الحذف.');
    } finally {
      if (mounted.current) setBusy(false);
    }
  };

  const openPicker = async (mode) => {
    setMenuOpen(false);
    try {
      setAlbums(await Media.listAlbums());
      setPickerMode(mode);
    } catch {
      Alert.alert('Error', 'Could not list folders.');
    }
  };

  const runPick = async (targetAlbum) => {
    const mode = pickerMode;
    setPickerMode(null);
    setBusy(true);
    try {
      const fn = mode === 'copy' ? Media.copyAssets : Media.moveAssets;
      startProgress(mode === 'copy' ? 'نسخ' : 'نقل', selectedAssets.length);
      const moved = selectedAssets;
      await fn(moved, targetAlbum);
      clearSel();
      if (mode === 'move' && album) {
        const ids = new Set(moved.map((x) => x.id));
        setAssets((prev) => prev.filter((x) => !ids.has(x.id)));
      }
      InteractionManager.runAfterInteractions(() => { if (mounted.current) load(); });
    } catch {
      Alert.alert('Error', 'Operation failed.');
    } finally {
      endProgress();
      if (mounted.current) setBusy(false);
    }
  };

  const selectAll = () => { setSelected(new Set(assets.map((a) => a.id))); setMenuOpen(false); };

  const menuItems = [
    { label: 'نسخ', icon: 'copy-outline', onPress: () => openPicker('copy') },
    { label: 'نقل', icon: 'move-outline', onPress: () => openPicker('move') },
    favoritesOnly ? { label: 'إزالة من المفضلة', icon: 'heart-dislike-outline', onPress: removeFavorites } : { label: 'إضافة للمفضلة', icon: 'heart-outline', onPress: addFavorites },
  ];

  const renderItem = useCallback(({ item }) => {
    const isSel = selected.has(item.id);
    return (
      <Pressable
        style={styles.tile}
        onPressIn={() => {
          longFired.current = false;
          clearTimeout(pressTimer.current);
          pressTimer.current = setTimeout(() => {
            longFired.current = true;
            setSelected((prev) => new Set(prev).add(item.id));
          }, 350);
        }}
        onPressOut={() => clearTimeout(pressTimer.current)}
        onPress={() => {
          if (longFired.current) { longFired.current = false; return; }
          if (selecting) toggle(item.id);
          else navigation.navigate('Viewer', { assets: sortedRef.current, index: sortedRef.current.findIndex((a) => a.id === item.id), folderTitle: album?.title ?? null });
        }}
      >
        <Thumb asset={item} />
        {item.mediaType === 'video' && (
          <View style={styles.badge}>
            <Ionicons name="play" size={10} color="#fff" />
            <Text style={styles.dur}>{fmt(item.duration)}</Text>
          </View>
        )}
        {favorites.has(item.id) && <Ionicons name="heart" size={12} color={colors.danger} style={styles.fav} />}
        {isSel && (
          <View style={styles.selOverlay}>
            <Ionicons name="checkmark-circle" size={22} color={colors.accent} />
          </View>
        )}
      </Pressable>
    );
  }, [favorites, selected, selecting, navigation, styles, colors, album]);

  const title = favoritesOnly ? 'المفضلة' : (album?.title ?? 'Gallery Pro');
  const leftIcon = selecting ? 'close' : album ? 'arrow-back' : null;
  const onLeft = () => (selecting ? clearSel() : navigation.goBack());

  const header = (
    <View style={[styles.bar, { paddingTop: insets.top + 8 }]}>
      {selecting || album || favoritesOnly ? (
        <Pressable onPress={onLeft} hitSlop={12}>
          <Ionicons name={selecting ? 'close' : 'arrow-back'} size={24} color={colors.text} />
        </Pressable>
      ) : (
        <Pressable onPress={() => navigation.navigate('Favorites')} hitSlop={12}>
          <Ionicons name="heart-outline" size={22} color="#fff" />
        </Pressable>
      )}
      <Text style={styles.title} numberOfLines={1}>{selecting ? `${selected.size} محدد` : title}</Text>
      {selecting ? (
        <View style={{ flexDirection: 'row', gap: 16, alignItems: 'center' }}>
          <Pressable onPress={shareSelected} hitSlop={10}>
            <Ionicons name="share-social-outline" size={22} color="#FFFFFF" />
          </Pressable>
          <Pressable onPress={selectAll} hitSlop={10}>
            <Ionicons name="checkmark-done-outline" size={22} color={colors.text} />
          </Pressable>
          <Pressable onPress={doDelete} hitSlop={10}>
            <Ionicons name="trash-outline" size={22} color="#FFFFFF" />
          </Pressable>
          <Pressable onPress={() => setMenuOpen(true)} hitSlop={10}>
            <Ionicons name="ellipsis-vertical" size={22} color={colors.text} />
          </Pressable>
        </View>
      ) : (
        <View style={{ flexDirection: 'row', gap: 16, alignItems: 'center' }}>
          {!album && !favoritesOnly && (
            <Pressable onPress={() => setSearchOpen((v) => !v)} hitSlop={10}>
              <Ionicons name="search" size={22} color={colors.text} />
            </Pressable>
          )}
          <Pressable onPress={() => setSortOpen(true)} hitSlop={10}>
            <Ionicons name="swap-vertical" size={22} color={colors.text} />
          </Pressable>
          {!album && !favoritesOnly && (
            <Pressable onPress={() => navigation.navigate('Settings')} hitSlop={10}>
              <Ionicons name="settings-outline" size={22} color={colors.text} />
            </Pressable>
          )}
        </View>
      )}
    </View>
  );

  if (permitted === false) {
    return (
      <View style={[styles.root, styles.center, { paddingTop: insets.top }]}>
        <Ionicons name="lock-closed" size={44} color={colors.muted} />
        <Text style={styles.msg}>Media access is required to show your photos and videos.</Text>
        <Pressable style={styles.btn} onPress={load}><Text style={styles.btnText}>Grant access</Text></Pressable>
        <Pressable style={[styles.btn, styles.btnAlt]} onPress={Media.openAllFilesAccess}>
          <Text style={styles.btnText}>Open All Files Access</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={styles.root}>
      {header}
      {searchOpen && !album && !favoritesOnly && (
        <View style={styles.searchRow}>
          <Ionicons name="search" size={18} color={colors.muted} />
          <TextInput
            autoFocus
            value={query}
            onChangeText={setQuery}
            placeholder="ابحث بالاسم"
            placeholderTextColor={colors.muted}
            style={styles.searchInput}
            returnKeyType="search"
          />
          <Pressable onPress={() => { setQuery(''); setSearchOpen(false); }} hitSlop={10}>
            <Ionicons name="close" size={20} color={colors.text} />
          </Pressable>
        </View>
      )}
      {!album && !favoritesOnly && !selecting && (
        <View style={styles.tabs}>
          {[['photo', 'الصور'], ['video', 'الفيديوهات']].map(([k, l]) => (
            <Pressable key={k} onPress={() => startTransition(() => setMediaFilter(mediaFilter === k ? null : k))} style={styles.tab}>
              <Text style={[styles.tabText, mediaFilter === k && styles.tabTextOn]}>{l}</Text>
              <View style={[styles.tabLine, mediaFilter === k && styles.tabLineOn]} />
            </Pressable>
          ))}
        </View>
      )}
      {loading && assets.length === 0 && <ActivityIndicator style={{ marginTop: 40 }} color={colors.accent} />}
      {!loading && permitted && assets.length === 0 && <Text style={styles.msg}>No photos or videos found.</Text>}
      <FlatList
        ref={listRef}
        data={sorted}
        showsVerticalScrollIndicator={false}
        onScroll={onScrollList}
        scrollEventThrottle={16}
        onContentSizeChange={(_w, h) => { contentH.current = h; }}
        onLayout={(e) => { viewH.current = e.nativeEvent.layout.height; }}
        refreshControl={
          <RefreshControl
            refreshing={loading && assets.length > 0}
            onRefresh={load}
            colors={[colors.accent]}
            progressBackgroundColor={colors.surface}
            tintColor={colors.accent}
          />
        }
        keyExtractor={(a) => a.id}
        numColumns={COLS}
        getItemLayout={(_, i) => ({ length: SIZE + GAP, offset: (SIZE + GAP) * i, index: i })}
        initialNumToRender={30}
        maxToRenderPerBatch={30}
        renderItem={renderItem}
        extraData={[selected, favorites]}
        initialNumToRender={24}
        maxToRenderPerBatch={24}
        windowSize={5}
        updateCellsBatchingPeriod={50}
        removeClippedSubviews
        columnWrapperStyle={{ gap: GAP }}
        contentContainerStyle={{ gap: GAP, paddingBottom: insets.bottom + 90 }}
      />
      {!selecting && sections.length > 0 && (
        <DateScrubber
          anim={scrollAnim}
          label={scrollLabel}
          show={showScrub}
          onDrag={dragTo}
          top={insets.top + 110}
          bottom={insets.bottom + 90}
        />
      )}
      <ConfirmDialog
        visible={confirmDel}
        title="حذف"
        message={`نقل ${selectedAssets.length} عنصر إلى السلة؟ يمكن استرجاعه خلال 30 يوماً.`}
        confirmText="حذف"
        onCancel={() => setConfirmDel(false)}
        onConfirm={() => { setConfirmDel(false); runDelete(); }}
      />
      {busy && (
        <View style={styles.busy}><ActivityIndicator color="#fff" /></View>
      )}

      <Modal visible={sortOpen} transparent animationType="fade" onRequestClose={() => setSortOpen(false)}>
        <Pressable style={styles.scrim} onPress={() => setSortOpen(false)}>
          <View style={[styles.menu, { marginTop: insets.top + 50 }]}>
            {SORTS.map((o) => (
              <Pressable key={o.key} style={styles.menuRow} onPress={() => { setSortMode(o.key); setSortOpen(false); }}>
                <Ionicons name={sortMode === o.key ? 'radio-button-on' : 'radio-button-off'} size={18} color={colors.accent} />
                <Text style={styles.menuText}>{o.label}</Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>

      <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
        <Pressable style={styles.scrim} onPress={() => setMenuOpen(false)}>
          <View style={[styles.menu, { marginTop: insets.top + 50 }]}>
            {menuItems.map((m) => (
              <Pressable key={m.label} style={styles.menuRow} onPress={m.onPress}>
                <Ionicons name={m.icon} size={20} color={m.danger ? colors.danger : colors.text} />
                <Text style={[styles.menuText, m.danger && { color: colors.danger }]}>{m.label}</Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>

      <Modal visible={!!pickerMode} transparent animationType="slide" onRequestClose={() => setPickerMode(null)}>
        <View style={styles.sheetWrap}>
          <View style={[styles.sheet, { paddingBottom: insets.bottom + 16 }]}>
            <Text style={styles.sheetTitle}>{pickerMode === 'copy' ? 'نسخ إلى' : 'نقل إلى'}</Text>
            <FlatList
              data={[{ id: '__default', title: 'Gallery Pro (default)' }, ...albums]}
              keyExtractor={(a) => a.id}
              renderItem={({ item }) => (
                <Pressable style={styles.menuRow} onPress={() => runPick(item.id === '__default' ? null : item)}>
                  <Text style={styles.menuText}>{item.title}</Text>
                </Pressable>
              )}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const makeStyles = (colors) => StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  center: { alignItems: 'center', justifyContent: 'center', gap: 16, padding: 24 },
  bar: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 10, backgroundColor: colors.surface },
  title: { color: colors.text, fontSize: 18, fontWeight: '700', flex: 1, textAlign: 'center', marginHorizontal: 8 },
  msg: { color: colors.muted, textAlign: 'center', marginTop: 40 },
  tile: { width: SIZE, height: SIZE, backgroundColor: colors.surfaceAlt, marginRight: 0 },
  img: { width: '100%', height: '100%' },
  videoTile: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  badge: { position: 'absolute', left: 4, bottom: 4, flexDirection: 'row', alignItems: 'center', gap: 2, backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 4, paddingHorizontal: 4, paddingVertical: 1 },
  dur: { color: '#fff', fontSize: 10 },
  fav: { position: 'absolute', right: 4, top: 4 },
  selOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(47,107,255,0.25)', alignItems: 'flex-end', padding: 4 },
  btn: { backgroundColor: colors.accent, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10, minWidth: 220, alignItems: 'center' },
  btnAlt: { backgroundColor: colors.surfaceAlt },
  btnText: { color: '#fff', fontWeight: '600' },
  busy: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' },
  scrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'flex-end', paddingRight: 12 },
  menu: { backgroundColor: colors.surface, borderRadius: 12, minWidth: 210, paddingVertical: 6, borderWidth: 1, borderColor: colors.border },
  menuRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 16, paddingVertical: 13 },
  menuText: { color: colors.text, fontSize: 15 },
  sheetWrap: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: { backgroundColor: colors.surface, borderTopLeftRadius: 16, borderTopRightRadius: 16, maxHeight: '70%', paddingTop: 12 },
  chips: { flexDirection: 'row', gap: 8, paddingHorizontal: 16, paddingVertical: 8, backgroundColor: colors.bg },
  chip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 14, backgroundColor: colors.surfaceAlt },
  chipOn: { backgroundColor: colors.accent },
  chipText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  scrubWrap: { position: 'absolute', right: 0, width: 28 },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginVertical: 8, paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12, backgroundColor: colors.surfaceAlt },
  searchInput: { flex: 1, color: colors.text, fontSize: 15, paddingVertical: 6 },
  tabs: { flexDirection: 'row', backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.border },
  tab: { flex: 1, alignItems: 'center', paddingTop: 10 },
  tabText: { color: colors.muted, fontSize: 15, fontWeight: '600', paddingBottom: 8 },
  tabTextOn: { color: colors.text },
  tabLine: { height: 3, width: '60%', borderRadius: 2, backgroundColor: 'transparent' },
  tabLineOn: { backgroundColor: colors.accent },
  sheetTitle: { color: colors.text, fontSize: 16, fontWeight: '700', paddingHorizontal: 16, paddingBottom: 8 },
});
