import 'react-native-gesture-handler';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import * as NavigationBar from 'expo-navigation-bar';
import * as SystemUI from 'expo-system-ui';
import GalleryScreen from './src/screens/GalleryScreen';
import FoldersScreen from './src/screens/FoldersScreen';
import ViewerScreen from './src/screens/ViewerScreen';
import TrashScreen from './src/screens/TrashScreen';
import TrashViewer from './src/screens/TrashViewer';
import SettingsScreen from './src/screens/SettingsScreen';
import UndoBar from './src/components/UndoBar';
import ProgressOverlay from './src/components/ProgressOverlay';
import { purgeOldTrash } from './src/services/trash';
import { loadThumbIndex } from './src/services/thumbs';
import { loadSettings, saveSettings } from './src/services/settings';
import { AppContext, THEMES, DEFAULT_SETTINGS, useThemeColors } from './src/theme';

const Stack = createNativeStackNavigator();
const Tabs = createBottomTabNavigator();

function TabsScreen() {
  const colors = useThemeColors();
  return (
    <Tabs.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border },
        tabBarActiveTintColor: colors.accent,
        tabBarInactiveTintColor: colors.muted,
        tabBarIcon: ({ color, size }) => (
          <Ionicons name={route.name === 'Photos' ? 'images' : 'folder'} size={size} color={color} />
        ),
      })}
    >
      <Tabs.Screen name="Photos" component={GalleryScreen} />
      <Tabs.Screen name="Folders" component={FoldersScreen} />
    </Tabs.Navigator>
  );
}

function Root() {
  const colors = useThemeColors();
  const navTheme = useMemo(() => ({
    ...DefaultTheme,
    dark: true,
    colors: {
      ...DefaultTheme.colors,
      background: colors.bg,
      card: colors.surface,
      text: colors.text,
      border: colors.border,
      primary: colors.accent,
    },
  }), [colors]);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <NavigationContainer theme={navTheme}>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen name="Tabs" component={TabsScreen} />
            <Stack.Screen name="Folder" component={GalleryScreen} />
            <Stack.Screen name="Favorites" component={GalleryScreen} initialParams={{ favoritesOnly: true }} />
            <Stack.Screen name="Trash" component={TrashScreen} />
            <Stack.Screen name="TrashViewer" component={TrashViewer} options={{ animation: 'fade' }} />
            <Stack.Screen name="Settings" component={SettingsScreen} />
            <Stack.Screen name="Viewer" component={ViewerScreen} options={{ animation: 'fade' }} />
          </Stack.Navigator>
        </NavigationContainer>
        <UndoBar />
        <ProgressOverlay />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);

  useEffect(() => {
    purgeOldTrash();
    Promise.all([
      loadThumbIndex(),
      loadSettings().then((s) => setSettings(s)),
    ]).finally(() => setReady(true));
    NavigationBar.setButtonStyleAsync('light').catch(() => {});
  }, []);

  const update = useCallback((patch) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const ctx = useMemo(() => ({
    settings,
    update,
    colors: THEMES[settings.theme] ?? THEMES.black,
  }), [settings, update]);

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(ctx.colors.bg).catch(() => {});
  }, [ctx.colors.bg]);

  if (!ready) return null;
  return (
    <AppContext.Provider value={ctx}>
      <Root />
    </AppContext.Provider>
  );
}
