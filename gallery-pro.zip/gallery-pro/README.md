# Gallery Pro 2

معرض صور وفيديو لأندرويد يعمل دون إنترنت، بلا إعلانات، وبلا حسابات.
An offline Android gallery app: no internet, no ads, no accounts.

See GALLERY_PRO_INSTRUCTIONS.md (in the archive root) for build steps, features, and the test checklist.
